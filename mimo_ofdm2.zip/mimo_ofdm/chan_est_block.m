function [H1_est,H2_est,Data]=chan_est_block(data_pilot,interval,complex_gold,Nps)
idx=1;
pilot_loc1=[];
pilot_loc2=[];
data_loc=[];
while idx<=size(data_pilot,2)   
    if mod(idx,interval)==1
        pilot_loc1 = [pilot_loc1 idx]; 
        pilot_loc2 = [pilot_loc2 idx+1];
        idx=idx+2;
    else
        data_loc=[data_loc,idx];
        idx=idx+1;
    end
end
rx_pilot1=data_pilot(:,pilot_loc1);
rx_pilot2=data_pilot(:,pilot_loc2);
Data=data_pilot(:,data_loc);%�ҵ�һ��ofdm���������ݷ���
len=size(rx_pilot1,2);
gold_tmp=kron(ones(1,len),complex_gold);
H1_tmp=rx_pilot1./gold_tmp;
H2_tmp=rx_pilot2./gold_tmp;
%interpolate
% Nfft=size(data_pilot,1);
% H1_tmp=H1_tmp(1,:);
% H2_tmp=H2_tmp(1,:);
% inter_index=1:size(data_pilot,2);
% H1_est=interp1(pilot_loc1,H1_tmp,inter_index,'cubic');
% H2_est=interp1(pilot_loc2,H2_tmp,inter_index,'cubic');
% H1_est=H1_est(data_loc);
% H1_est=kron(H1_est,ones(Nfft,1));
% H2_est=H2_est(data_loc);
% H2_est=kron(H2_est,ones(Nfft,1));
H1_est=kron(H1_tmp,ones(1,Nps));
H2_est=kron(H2_tmp,ones(1,Nps));
