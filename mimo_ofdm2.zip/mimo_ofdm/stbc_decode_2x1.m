function R_Data=stbc_decode_2x1(H1_est,H2_est,input_data,flag)
[carrier_count,NumLoop]=size(input_data);
R_Data = zeros(carrier_count,NumLoop);
y=input_data;
if flag==1
for ii= 1:carrier_count
    for jj = 1:2:NumLoop-1
        tmp_y=[y(ii,jj);conj(y(ii,jj+1))];
        tmp_H=[H1_est(ii,jj),H2_est(ii,jj);conj(H2_est(ii,jj)),-conj(H1_est(ii,jj))];
        tmp_H_power=abs(H1_est(ii,jj))^2+abs(H2_est(ii,jj))^2;
%         R_Data(ii,jj:jj+1)=tmp_H'*tmp_y./(tmp_H_power); 
        R_Data(ii,jj:jj+1)=pinv(tmp_H)*tmp_y;
    end
end
end
if flag==2
    sq2=sqrt(2)/2;
    constellation=[sq2+1j*sq2 sq2+1j*sq2 sq2+1j*sq2 sq2+1j*sq2 sq2-1j*sq2 sq2-1j*sq2 sq2-1j*sq2 sq2-1j*sq2 -sq2-1j*sq2 -sq2-1j*sq2 -sq2-1j*sq2 -sq2-1j*sq2 -sq2+1j*sq2 -sq2+1j*sq2 -sq2+1j*sq2 -sq2+1j*sq2;...
        sq2+1j*sq2 sq2-1j*sq2 -sq2-1j*sq2 -sq2+1j*sq2 sq2+1j*sq2 sq2-1j*sq2 -sq2-1j*sq2 -sq2+1j*sq2 sq2+1j*sq2 sq2-1j*sq2 -sq2-1j*sq2 -sq2+1j*sq2 sq2+1j*sq2 sq2-1j*sq2 -sq2-1j*sq2 -sq2+1j*sq2];
    for ii=1:carrier_count
        for jj=1:2:NumLoop-1
            dis=zeros(1,16);
            tmp_y=[y(ii,jj);conj(y(ii,jj+1))];
            tmp_H=[H1_est(ii,jj),H2_est(ii,jj);conj(H2_est(ii,jj)),-conj(H1_est(ii,jj))];
            for idx=1:16
                dis(idx)=sum(abs(tmp_y-tmp_H*constellation(:,idx)).^2);
            end
            [value,loc]=min(dis);
            R_Data(ii,jj:jj+1)=constellation(:,loc).';
        end
    end
end
