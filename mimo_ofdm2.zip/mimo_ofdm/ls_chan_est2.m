function [H1,H2]=ls_chan_est2(rx_pilot1,rx_pilot2,pilot_symbol,Nfft)

[pilot_count,frame_num]=size(rx_pilot1);
Nd=Nfft-2*pilot_count;
matrix_pilot=kron(ones(1,frame_num),pilot_symbol);
LS_est1=rx_pilot1./matrix_pilot;
LS_est2=rx_pilot2./matrix_pilot;
H1=zeros(Nd,frame_num);
H2=zeros(Nd,frame_num);

H1(1:2:end,:)=LS_est1;
H1(2:2:end,:)=LS_est1;
H2(1:2:end,:)=LS_est2;
H2(2:2:end,:)=LS_est2;
end
%interpolate
% % inter_index=1:Nfft;
% if pilot_loc1(Np)<Nfft
%     a=(LS_est1(Np)-LS_est1(Np-1))/(pilot_loc1(Np)-pilot_loc1(Np-1));
%     end_est=LS_est1(Np)+a*(Nfft-pilot_loc1(Np));
%     LS_est1=[LS_est1 end_est];
%     pilot_loc1=[pilot_loc1 Nfft];
% end
% % H1_est=interp1(pilot_loc1,LS_est1,inter_index,'linear');%��ɲ�ֵfft����
% if pilot_loc2(Np)<Nfft
%     a=(LS_est2(Np)-LS_est2(Np-1))/(pilot_loc2(Np)-pilot_loc2(Np-1));
%     end_est=LS_est2(Np)+a*(Nfft-pilot_loc2(Np));
%     LS_est2=[LS_est2 end_est];
%     pilot_loc2=[pilot_loc2 Nfft];
% end



