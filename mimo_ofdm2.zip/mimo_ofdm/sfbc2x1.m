function [encode_data1,encode_data2]=sfbc2x1(data,Nfft,frame_num)%data������
carrier_count=Nfft;
Sym=data;
NumLoop=frame_num;
encode_data1 = zeros(carrier_count,NumLoop);
encode_data2 = zeros(carrier_count,NumLoop);
SymIFFTtmp = reshape(Sym,carrier_count,NumLoop);
for ii=1:2:carrier_count  %alamouti���벢����ת��
    encode_data1(ii,:)=SymIFFTtmp(ii,:);
    encode_data2(ii,:)=SymIFFTtmp(ii+1,:);
    encode_data1(ii+1,:)=-conj(SymIFFTtmp(ii+1,:));
    encode_data2(ii+1,:)=conj(SymIFFTtmp(ii,:));
end 
end