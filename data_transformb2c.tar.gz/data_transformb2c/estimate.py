#!/usr/bin/env python2
# -*- coding: utf-8 -*

#####################################
###该函数用于实现信道估计，输入参数是采样率，发送训练序列和接收训练序列的保存文件
###注意字符形式的二进制序列和数字形式的转换，for循环使用emurate
###fft，ifft横坐标和纵坐标关系
#####################################
import numpy as np
from scipy.fftpack import fft, ifft
import matplotlib.pyplot as plt
import types

def estimate(samp_rate, filename_tx, filename_rx):

    #将收发的训练序列从文本转为数字
    str_filename_r_tx = '/home/wzy/siso_data/'+filename_tx
    str_filename_r_rx = '/home/wzy/siso_data/'+filename_rx
    fr_tx = open(str_filename_r_tx, "r")
    tx_data = []
    rx_data = []

    while 1:
        str_read = fr_tx.readline().strip('\n')
        if str_read == '':
            break
        for index, item in enumerate(list(str_read)):
            tx_data.append(float(item))
    fr_tx.close()
    tx_array = np.array(tx_data)

    fr_rx = open(str_filename_r_rx, 'r')
    while 1:
        str_read = fr_rx.readline().strip('\n')
        if str_read == '':
            break
        for index, item in enumerate(list(str_read)):
            rx_data.append(float(item))
    fr_rx.close()
    rx_array = np.array(rx_data)
    #print(tx_array)
    #print('\n')
    #print(rx_array)
    #print('\n')

    #本次实验中，收发序列大小不同，需要找到最小值作为fft点数
    tx_len = len(tx_array)
    rx_len = len(rx_array)
    print('tx_len=%d\n' % tx_len)
    print('rx_len=%d\n' % rx_len)
    fft_num = int(min(tx_len, rx_len))
    #if type(fft_num) == type(1):
        #print('fft_num is int')
    #fft_num = int(4e4)
    print('fft_num=%d\n' % fft_num)
    tx_array = tx_array[0:fft_num]
    rx_array = rx_array[0:fft_num]

    #收发进行fft，得到频域响应，并将幅值保存
    fft_tx = fft(tx_array)*1.0/fft_num
    #print('fft_tx_len=%d\n' % len(fft_tx))
    #y_tx = np.abs(fft_tx)/fft_num
    fft_rx = fft(rx_array)*1.0/fft_num
    #print('fft_rx_len=%d\n' % len(fft_rx))
    #y_rx = np.abs(fft_rx)/fft_num
    fft_h = fft_rx/fft_tx
    fw = open('channel_response(f).txt', 'w')
    for i in fft_h:
        fw.write(str(abs(fft_h[int(i)])))
        fw.write('\n')
    fw.close()
    #绘制频域响应的曲线
    df = samp_rate*1.0/fft_num
    frequency = np.arange(0, df*fft_num, df)
    #frequency = np.arange(-fft_num/2, fft_num/2)*samp_rate*1.0/fft_num
    #frequency = np.arange(fft_num)*samp_rate*1.0/fft_num
    abs_fft = 2*np.abs(fft_h)
    plt.figure(1)
    plt.plot(frequency[0:int(fft_num/2)], abs_fft[0:int(fft_num/2)])
    plt.title('channel transfer function estimate(f)')
    plt.xlabel('frequency(Hz)')
    plt.ylabel('magnitude')
    #plt.xlim(-2e3, 2e3)
    plt.show()

    #ifft变为时域响应，保存幅值
    h = ifft(fft_h)
    abs_h = np.abs(h)
    t = np.arange(fft_num)*1.0/samp_rate
    fw = open('channel_response(t).txt', 'w')
    for i in fft_h:
        fw.write(str(abs(h[int(i)])))
        fw.write('\n')
    fw.close()
    #绘制时域响应曲线
    plt.figure(2)
    plt.plot(t, abs_h)
    plt.title('channel transfer function estimate(t)')
    plt.xlabel('time(s)')
    plt.ylabel('magnitude')
    #plt.xlim(0, 0.001)
    plt.show()

estimate(2e5, 'char_gen3.txt', 'char_inb3.txt')




