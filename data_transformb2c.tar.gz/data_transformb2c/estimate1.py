#!/usr/bin/env python2
# -*- coding: utf-8 -*

import numpy as np
from scipy.fftpack import fft
import matplotlib.pyplot as plt
import types

def estimate(samp_rate, filename_tx, filename_rx):
    str_filename_r_tx = '/home/wzy/siso_data/'+filename_tx
    str_filename_r_rx = '/home/wzy/siso_data/'+filename_rx
    fr_tx = open(str_filename_r_tx, "rb")
    tx_data = []
    rx_data = []
    str_read = fr_tx.read()
    tx_data.append(str_read)
    fr_tx.close()
    tx_array = np.array(tx_data)

    fr_rx = open(str_filename_r_rx, 'r')
    str_read = fr_rx.read()
    rx_data.append(str_read)
    fr_rx.close()
    rx_array = np.array(rx_data)
    #print(tx_array)
    #print('\n')
    #print(rx_array)
    #print('\n')

    tx_len = len(tx_array)
    rx_len = len(rx_array)
    print('tx_len=%d\n' % tx_len)
    print('rx_len=%d\n' % rx_len)
    fft_num = min(tx_len, rx_len)
    #if type(fft_num) == type(1):
        #print('fft_num is int')
    #print('fft_num=%d\n' % fft_num)
    tx_array = tx_array[0:fft_num]
    rx_array = rx_array[0:fft_num]

    fft_tx = fft(tx_array)
    #print('fft_tx_len=%d\n' % len(fft_tx))
    y_tx = np.abs(fft_tx)/fft_num
    fft_rx = fft(rx_array)
    #print('fft_rx_len=%d\n' % len(fft_rx))
    y_rx = np.abs(fft_rx)/fft_num
    fft_h = y_rx/y_tx
    frequency = np.arange(-fft_num/2, fft_num/2)*samp_rate*1.0/fft_num
    plt.figure(1)
    plt.plot(frequency, fft_h)
    plt.title('channel transfer function estimate')
    plt.xlabel('frequency(Hz)')
    plt.ylabel('gain')
    plt.show()


estimate(2e5, 'gen2.txt', 'inb2.txt')




