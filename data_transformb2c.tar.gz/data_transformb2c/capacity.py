#!/usr/bin/env python2
# -*- coding: utf-8 -*

###############################
###本函数用于计算awgn信道容量和衰落信道遍历容量
###本次实验没有测量发射端的SNR，只测量了接受端的SNR，所以没有使用信道响应，而是直接使用接受SNR
###接收SNR是算法估计的结果，可能存在误差
###############################

import numpy as np
import math


def awgn_capacity(filename):
    str_filename_r = '/home/wzy/siso_data/' + "del_nan_" + filename
    fr_tx = open(str_filename_r, "r")
    temp = []
    while 1:
        str_read = fr_tx.readline().strip('\n')
        if str_read == '':
            break
        temp.append(float(str_read))
    fr_tx.close()
    snr_data = np.array(temp)
    #temp_snr = 0
    #for i in range(len(snr_data)):
        #temp_snr = temp_snr+math.pow(10, snr_data[i]/10.0)
    #ave_snr = temp_snr/len(snr_data)
    ave_snr_dB = np.sum(snr_data)*1.0/len(snr_data)
    ave_snr = math.pow(10, ave_snr_dB/10.0)
    print('average snr=%f(dB)\n' % ave_snr_dB)
    ave_capacity = math.log2(1 + ave_snr)
    print('awgn capacity=%f(bit/s/Hz)\n' % ave_capacity)


def ergodic_capacity(filename):
    str_filename_r = '/home/wzy/siso_data/' +  "del_nan_" + filename
    fr_tx = open(str_filename_r, "r")
    temp = []
    while 1:
        str_read = fr_tx.readline().strip('\n')
        if str_read == '':
            break
        temp.append(float(str_read))
    fr_tx.close()
    snr_data = np.array(temp)
    capacity = np.zeros(snr_data.shape[0])

    for i in range(len(snr_data)):
        temp_snr = math.pow(10, snr_data[i]/10.0)
        #rint (snr_data[i])
        #print (temp_snr)
        capacity[i] = math.log2(1+temp_snr)
    ave_capacity = np.sum(capacity)*1.0/len(snr_data)
    print('ergodic channel capacity=%f(bit/s/Hz)\n' % ave_capacity)


awgn_capacity('snr1.txt')
ergodic_capacity('snr1.txt')