#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 24 21:51:49 2018

@author: wzy
"""
import matplotlib as mpl
#mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

# 添加数据标签
def add_labels(rects):
    for rect in rects:
        height = rect.get_height()
        plt.text(rect.get_x() + rect.get_width() / 2, height, height, ha='center', va='bottom')
        # 柱形图边缘用白色填充，纯粹为了美观
        rect.set_edgecolor('white')


custom_font = mpl.font_manager.FontProperties(fname='zh.ttf')
font_size = 10 # 字体大小
fig_size = (8, 6) # 图表大小

distance=[1.0,1.5,2.0]
distance_name=[u'1.0米',u'1.5米',u'2.0米']
frequency=[26,30]
poly_snr=[4.215400,2.485130,8.836723,8.766278,9.789339,10.398035]
poly_capacity=[2.023710,2.174184,3.176158,3.151768,3.436098,3.615403]
poly_ber=[2.9292E-03,1.7793E-03,3.2212E-03,1.9650E-03,1.4199E-02,1.3758E-03]
polycc_snr=[6.764202,8.255732,7.874843,7.735094,8.201991,8.375524]
polycc_capacity=[2.649105,3.000161,2.902952,2.845489,2.993542,3.040912]
polycc_ber=[5.9932E-04,8.4628E-04,8.4868E-04,8.7898E-04,3.1225E-03,5.8672E-04]

#更新字体大小
mpl.rcParams['font.size'] = font_size
# 更新图表大小
mpl.rcParams['figure.figsize'] = fig_size
#set bar width
bar_width = 0.3

names=[u'无卷积码',u'加入卷码']
index=np.arange(3)
# plot ber without convolution encode
poly=plt.bar(index,poly_ber[0:3],bar_width,color='#0072BC', label=names[0])
#plot bar with convolution encode
for i in range(3):
    index[i]=index[i]+bar_width
polycc = plt.bar(index, polycc_ber[0:3], bar_width, color='#ED1C24', label=names[1])
plt.xticks(index + bar_width, distance_name, fontproperties=custom_font)
# 图表标题
plt.title(u'卷积码误码率对比', fontproperties=custom_font)
# 图例显示在图表下方
plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.03), fancybox=True, ncol=5, prop=custom_font)
# 添加数据标签
add_labels(poly)
add_labels(polycc)
plt.show()