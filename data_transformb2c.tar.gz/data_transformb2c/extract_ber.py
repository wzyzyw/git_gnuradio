#!/usr/bin/env python2
# -*- coding: utf-8 -*-
###################################
###该程序将保存ber文件中的多余字符删除，只保留ber的值
###python find()函数
###################################
def extract_ber(filename):
    str_filename_r = "/home/wzy/siso_process/" + filename
    str_filename_w = "/home/wzy/siso_process/" + "del_" + filename
    fr = open(str_filename_r, "r")
    fw = open(str_filename_w, 'w')
    str_need='BER:'
    while 1:
        str_read = fr.readline()
        if str_read == '':
            break
        index = str_read.find(str_need)
        if index == -1:
            continue
        str_write = str_read[index+5:]
        fw.write(str_write)
    fr.close()
    fw.close()

extract_ber('ber3.txt')