#!/usr/bin/env python2
# -*- coding: utf-8 -*-
######################################
#发射的伪随机序列和接收的伪随机序列都是以二进制文件形式写入的
#此函数的作用是将二进制数据以文本形式写入txt
######################################
import os
import binascii
from functools import partial

def datab2c(filename):

    str_filename_r="/home/wzy/siso_process/"+filename
    str_filename_w="/home/wzy/siso_process/"+"char_"+filename
    i = 0
    fr = open(str_filename_r, "rb")
    fw = open(str_filename_w, 'w')
    ##partial函数是根据已知的部分参数重新形成新的函数
    ##iter是迭代函数，根据第二个参数阈值，不断向下执行，直到满足阈值
    ##b''表示空字节
    ##重定义后的read函数每次只读取一个比特（1位的字节），再将01比特转化为01整形和字符窜
    records = iter(partial(fr.read, 1), b'')
    for r in records:
        r_int = int.from_bytes(r, byteorder='big')  # 将 byte转化为 int
        #print("r_int=%d\n" %r_int)
        str_bin = bin(r_int).lstrip('0b')  # 将int转化为二进制字符
        fw.write(str(r_int))
        i += 1
        if i == 32:  # 以32bit为单位分行
            fw.write('\n')
            i =
    fr.close()
    fw.close()

datab2c("inb1.txt")