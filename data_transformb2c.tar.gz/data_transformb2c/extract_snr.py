#!/usr/bin/env python2
# -*- coding: utf-8 -*-
###################################
###该程序将保存snr文件中的-nan删除，保证程序的运行，但这样处理的方法比较简单，以后有更好的方法可以改进
###python文件读取函数都会读取每行结尾的换行符‘\n’，字符窜用“==”比较时，注意\n
###python文件读没有EOF判断文件读到末尾，用''空符号判断
###################################

def extract_snr(filename, del_str1, del_str2):
    str_filename_r = "/home/wzy/siso_data/" + filename
    str_filename_w = "/home/wzy/siso_data/" + "del_nan_" + filename
    fr = open(str_filename_r, "r")
    fw = open(str_filename_w, 'w')

    while 1:
        str_read = fr.readline()
        if str_read == del_str1:
            #print("equal1")
            continue
        if str_read == del_str2:
            #print("equal2")
            continue
        if str_read == '':
            break
        fw.write(str_read)
    fr.close()
    fw.close()


del_str1 = "-nan\n"
del_str2 = '******* MESSAGE DEBUG PRINT ********\n'
extract_snr('snr1.txt', del_str1, del_str2)


