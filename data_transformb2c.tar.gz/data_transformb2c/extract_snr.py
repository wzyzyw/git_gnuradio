#!/usr/bin/env python2
# -*- coding: utf-8 -*-
###################################
###该程序将保存snr文件中的多余字符删除，只保留snr的值
###python文件读取函数都会读取每行结尾的换行符‘\n’，字符窜用“==”比较时，注意\n
###python文件读没有EOF判断文件读到末尾，用''空符号判断
###################################

def extract_snr(filename, del_str1, del_str2):
    str_filename_r = "/home/wzy/siso_process/" + filename
    str_filename_w = "/home/wzy/siso_process/" + "del_" + filename+".txt"
    fr = open(str_filename_r, "r")
    fw = open(str_filename_w, 'w')

    while 1:
        str_read = fr.readline()
        if str_read == del_str1:
            #print("equal1")
            continue
        if str_read == del_str2:
            #print("equal2")
            continue
        if str_read == '':
            break
        fw.write(str_read)
    fr.close()
    fw.close()


del_str1 = "************************************\n"
del_str2 = '******* MESSAGE DEBUG PRINT ********\n'
extract_snr('snr3', del_str1, del_str2)


