#!/usr/bin/env python
# coding=utf-8
import numpy
from gnuradio import gr
import prbs_base
import time

class prbs_sink_b(gr.sync_block):
    def __init__(self, which_mode="PRBS31", reset_len=100000, skip=100000):
        gr.sync_block.__init__(self,
            name="prbs_sink_b",
            in_sig=[numpy.int8],
            out_sig=[])
        self.base = prbs_base.prbs_base(which_mode, reset_len)
        self.nbits = 0.0
        self.nerrs = 0.0
        self.skip  = skip
        #self.writting=writting
        #self.describe=describe
        localtime=time.localtime(time.time())
        with open('/home/wzy/grc_result/ber.txt', 'a') as f1:
            f1.write("start time is:\n")
            f1.write("year=%d \tmonth=%d \tday=%d \thour=%d \tminute=%d \tsecond=%d\n"
                %(localtime[0],localtime[1],localtime[2],localtime[3],localtime[4],localtime[5]))
        #("skip is:\n")
        #print(self.skip)

    def work(self, input_items, output_items):
        inb = input_items[0]
        gen = self.base.gen_n(len(inb))
        #print("sink n is:\n")
        #print(len(inb))
    #with open('/home/wzy/result/gen.txt','a') as f2:
            #f2.write(gen)
        if(self.nitems_read(0) > self.skip):
            # only count bit errors after first skip bits
            self.nerrs += numpy.sum(numpy.bitwise_xor(inb, gen).astype('float32'))
            self.nbits += len(inb)
        if self.nbits > 0:
            print "NBits: %d \tNErrs: %d \tBER: %.4E"%(int(self.nbits), int(self.nerrs), self.nerrs/self.nbits)

            with open('/home/wzy/grc_result/ber.txt', 'a') as f1:
                f1.write("NBits: %d \tNErrs: %d \tBER: %.4E\n"%(int(self.nbits),int(self.nerrs),self.nerrs/self.nbits))
            #print "NBits: %d \tNErrs: %d \tBER: %g"%(int(self.nbits), int(self.nerrs), self.nerrs/self.nbits)
        return len(inb)

