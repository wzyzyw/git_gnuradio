#!/usr/bin/python
import time
localtime=time.localtime(time.time())
print(localtime)
print(localtime[0])
print(localtime[1])