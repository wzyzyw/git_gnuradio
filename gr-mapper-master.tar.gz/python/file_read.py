#!/usr/bin/env python
# coding=utf-8
print ("inb is : \n")
with open('/home/wzy/result/inb.txt','rb') as f1:
    print (f1.read())
print ("gen is :\n")
with open('/home/wzy/result/gen.txt','rb') as f2:
    print (f2.read())