#!/usr/bin/env python2
# -*- coding: utf-8 -*-
##################################################
# GNU Radio Python Flow Graph
# Title: Top Block
# Generated: Thu Oct  4 23:27:16 2018
##################################################

if __name__ == '__main__':
    import ctypes
    import sys
    if sys.platform.startswith('linux'):
        try:
            x11 = ctypes.cdll.LoadLibrary('libX11.so')
            x11.XInitThreads()
        except:
            print "Warning: failed to XInitThreads()"

from PyQt4 import Qt
from cmath import exp, pi; from random import randint; import numpy as np;
from gnuradio import blocks
from gnuradio import channels
from gnuradio import digital
from gnuradio import eng_notation
from gnuradio import fec
from gnuradio import filter
from gnuradio import gr
from gnuradio import qtgui
from gnuradio.eng_option import eng_option
from gnuradio.filter import firdes
from gnuradio.qtgui import Range, RangeWidget
from optparse import OptionParser
import mapper
import my_preamble_pilot
import sip
import sys
from gnuradio import qtgui


class top_block(gr.top_block, Qt.QWidget):

    def __init__(self, eb=0.35, sps=2):
        gr.top_block.__init__(self, "Top Block")
        Qt.QWidget.__init__(self)
        self.setWindowTitle("Top Block")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except:
            pass
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("GNU Radio", "top_block")
        self.restoreGeometry(self.settings.value("geometry").toByteArray())

        ##################################################
        # Parameters
        ##################################################
        self.eb = eb
        self.sps = sps

        ##################################################
        # Variables
        ##################################################
        self.nfilts = nfilts = 32
        self.rrc_taps = rrc_taps = firdes.root_raised_cosine(nfilts, nfilts, 1.0/float(sps), eb, 5*sps*nfilts)
        self.mark_delays = mark_delays = [0, 0, 34, 56, 87, 119]
        self.sro = sro = 0.01
        self.samp_rate = samp_rate = 100e3
        self.samp_per_sym = samp_per_sym = 2
        self.preamble = preamble = [1 , -1 , -1 , 1 , 1 , -1 , -1 , -1 , -1 , 1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 , 1 , 1 , 1 , -1 , 1 , -1 , -1 , -1 , 1 , 1 , 1 , 1 , 1 , -1 , 1 , -1 , -1 , 1 , 1 , 1 , -1 , -1 , -1 , -1 , 1 , 1 , -1 , 1 , 1 , 1 , 1 , 1 , 1 , -1 , -1 , 1 , -1 , -1 , 1 , 1 , 1 , -1 , 1 , 1 , 1 , 1]
        self.pream = pream = (mapper.preamble_generator(32,511,1033)).get_preamble()
        self.matched_filter = matched_filter = firdes.root_raised_cosine(nfilts, nfilts, 1, eb, int(11*sps*nfilts))
        self.mark_delay = mark_delay = mark_delays[sps]
        self.gold_sequence = gold_sequence = [1 , 0 , 0 , 1 , 1 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 1 ,1 , 1 , 0 , 1 , 0 , 0 , 0 , 1 , 1 , 1 , 1 , 1 , 0 , 1 , 0 , 0 , 1 , 1 , 1 ,0 , 0 , 0 , 0 , 1 , 1 , 0 , 1 , 1 , 1 , 1 , 1 , 1 ,0 , 0 , 1 , 0 , 0 , 1 ,1 , 1 , 0 , 1 , 1 , 1 , 1]
        self.frame_width_with_pilot = frame_width_with_pilot = 2016*2+32+128
        self.frame_width_with_cc = frame_width_with_cc = 2016*2+32
        self.frame_width = frame_width = 1024*2
        self.filt_delay = filt_delay = 1+(len(rrc_taps)-1)/2


        self.enc = enc = map( (lambda a: fec.cc_encoder_make(2016, 7, 2, ([79,109]), 0, fec.CC_STREAMING, False)), range(0,1) );


        self.dec = dec = map( (lambda a: fec.cc_decoder.make(2016, 7, 2, ([79,109]), 0, -1, fec.CC_STREAMING, False)), range(0,1) );
        self.cfo = cfo = 0.01
        self.SNR = SNR = 20

        ##################################################
        # Blocks
        ##################################################
        self._sro_range = Range(-1e-1, 1e-1, 1e-3, 0.01, 200)
        self._sro_win = RangeWidget(self._sro_range, self.set_sro, 'Sample Rate Offset', "counter_slider", float)
        self.top_grid_layout.addWidget(self._sro_win)
        self._cfo_range = Range(-1e-1, 1e-1, 1e-3, 0.01, 200)
        self._cfo_win = RangeWidget(self._cfo_range, self.set_cfo, 'Freq Offset', "counter_slider", float)
        self.top_grid_layout.addWidget(self._cfo_win)
        self._SNR_tool_bar = Qt.QToolBar(self)
        self._SNR_tool_bar.addWidget(Qt.QLabel('SNR'+": "))
        self._SNR_line_edit = Qt.QLineEdit(str(self.SNR))
        self._SNR_tool_bar.addWidget(self._SNR_line_edit)
        self._SNR_line_edit.returnPressed.connect(
        	lambda: self.set_SNR(eng_notation.str_to_num(str(self._SNR_line_edit.text().toAscii()))))
        self.top_grid_layout.addWidget(self._SNR_tool_bar)
        self.root_raised_cosine_filter_0 = filter.interp_fir_filter_ccf(samp_per_sym, firdes.root_raised_cosine(
        	1, samp_rate, samp_rate/samp_per_sym, 0.35, 11))
        self.qtgui_time_sink_x_2_1_0_0 = qtgui.time_sink_c(
        	10240, #size
        	samp_rate, #samp_rate
        	'rm_preamble', #name
        	1 #number of inputs
        )
        self.qtgui_time_sink_x_2_1_0_0.set_update_time(0.10)
        self.qtgui_time_sink_x_2_1_0_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_2_1_0_0.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_2_1_0_0.enable_tags(-1, True)
        self.qtgui_time_sink_x_2_1_0_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_2_1_0_0.enable_autoscale(False)
        self.qtgui_time_sink_x_2_1_0_0.enable_grid(False)
        self.qtgui_time_sink_x_2_1_0_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_2_1_0_0.enable_control_panel(False)

        if not True:
          self.qtgui_time_sink_x_2_1_0_0.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in xrange(2):
            if len(labels[i]) == 0:
                if(i % 2 == 0):
                    self.qtgui_time_sink_x_2_1_0_0.set_line_label(i, "Re{{Data {0}}}".format(i/2))
                else:
                    self.qtgui_time_sink_x_2_1_0_0.set_line_label(i, "Im{{Data {0}}}".format(i/2))
            else:
                self.qtgui_time_sink_x_2_1_0_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_2_1_0_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_2_1_0_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_2_1_0_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_2_1_0_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_2_1_0_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_2_1_0_0_win = sip.wrapinstance(self.qtgui_time_sink_x_2_1_0_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_2_1_0_0_win)
        self.qtgui_time_sink_x_2_1_0 = qtgui.time_sink_c(
        	10240, #size
        	samp_rate, #samp_rate
        	'costas', #name
        	1 #number of inputs
        )
        self.qtgui_time_sink_x_2_1_0.set_update_time(0.10)
        self.qtgui_time_sink_x_2_1_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_2_1_0.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_2_1_0.enable_tags(-1, True)
        self.qtgui_time_sink_x_2_1_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_2_1_0.enable_autoscale(False)
        self.qtgui_time_sink_x_2_1_0.enable_grid(False)
        self.qtgui_time_sink_x_2_1_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_2_1_0.enable_control_panel(False)

        if not True:
          self.qtgui_time_sink_x_2_1_0.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in xrange(2):
            if len(labels[i]) == 0:
                if(i % 2 == 0):
                    self.qtgui_time_sink_x_2_1_0.set_line_label(i, "Re{{Data {0}}}".format(i/2))
                else:
                    self.qtgui_time_sink_x_2_1_0.set_line_label(i, "Im{{Data {0}}}".format(i/2))
            else:
                self.qtgui_time_sink_x_2_1_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_2_1_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_2_1_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_2_1_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_2_1_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_2_1_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_2_1_0_win = sip.wrapinstance(self.qtgui_time_sink_x_2_1_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_2_1_0_win)
        self.qtgui_time_sink_x_2_1 = qtgui.time_sink_c(
        	10240, #size
        	samp_rate, #samp_rate
        	'poly_sync', #name
        	1 #number of inputs
        )
        self.qtgui_time_sink_x_2_1.set_update_time(0.10)
        self.qtgui_time_sink_x_2_1.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_2_1.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_2_1.enable_tags(-1, True)
        self.qtgui_time_sink_x_2_1.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_2_1.enable_autoscale(False)
        self.qtgui_time_sink_x_2_1.enable_grid(False)
        self.qtgui_time_sink_x_2_1.enable_axis_labels(True)
        self.qtgui_time_sink_x_2_1.enable_control_panel(False)

        if not True:
          self.qtgui_time_sink_x_2_1.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in xrange(2):
            if len(labels[i]) == 0:
                if(i % 2 == 0):
                    self.qtgui_time_sink_x_2_1.set_line_label(i, "Re{{Data {0}}}".format(i/2))
                else:
                    self.qtgui_time_sink_x_2_1.set_line_label(i, "Im{{Data {0}}}".format(i/2))
            else:
                self.qtgui_time_sink_x_2_1.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_2_1.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_2_1.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_2_1.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_2_1.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_2_1.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_2_1_win = sip.wrapinstance(self.qtgui_time_sink_x_2_1.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_2_1_win)
        self.qtgui_time_sink_x_1_0_0 = qtgui.time_sink_c(
        	10240, #size
        	samp_rate, #samp_rate
        	'remove_pilot', #name
        	1 #number of inputs
        )
        self.qtgui_time_sink_x_1_0_0.set_update_time(0.10)
        self.qtgui_time_sink_x_1_0_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_1_0_0.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_1_0_0.enable_tags(-1, True)
        self.qtgui_time_sink_x_1_0_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_1_0_0.enable_autoscale(False)
        self.qtgui_time_sink_x_1_0_0.enable_grid(False)
        self.qtgui_time_sink_x_1_0_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_1_0_0.enable_control_panel(False)

        if not True:
          self.qtgui_time_sink_x_1_0_0.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in xrange(2):
            if len(labels[i]) == 0:
                if(i % 2 == 0):
                    self.qtgui_time_sink_x_1_0_0.set_line_label(i, "Re{{Data {0}}}".format(i/2))
                else:
                    self.qtgui_time_sink_x_1_0_0.set_line_label(i, "Im{{Data {0}}}".format(i/2))
            else:
                self.qtgui_time_sink_x_1_0_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_1_0_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_1_0_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_1_0_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_1_0_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_1_0_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_1_0_0_win = sip.wrapinstance(self.qtgui_time_sink_x_1_0_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_1_0_0_win)
        self.qtgui_time_sink_x_1 = qtgui.time_sink_c(
        	1024, #size
        	samp_rate, #samp_rate
        	'qpsk', #name
        	1 #number of inputs
        )
        self.qtgui_time_sink_x_1.set_update_time(0.10)
        self.qtgui_time_sink_x_1.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_1.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_1.enable_tags(-1, True)
        self.qtgui_time_sink_x_1.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_1.enable_autoscale(False)
        self.qtgui_time_sink_x_1.enable_grid(False)
        self.qtgui_time_sink_x_1.enable_axis_labels(True)
        self.qtgui_time_sink_x_1.enable_control_panel(False)

        if not True:
          self.qtgui_time_sink_x_1.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in xrange(2):
            if len(labels[i]) == 0:
                if(i % 2 == 0):
                    self.qtgui_time_sink_x_1.set_line_label(i, "Re{{Data {0}}}".format(i/2))
                else:
                    self.qtgui_time_sink_x_1.set_line_label(i, "Im{{Data {0}}}".format(i/2))
            else:
                self.qtgui_time_sink_x_1.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_1.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_1.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_1.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_1.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_1.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_1_win = sip.wrapinstance(self.qtgui_time_sink_x_1.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_1_win)
        self.qtgui_time_sink_x_0 = qtgui.time_sink_f(
        	1024, #size
        	samp_rate, #samp_rate
        	"", #name
        	1 #number of inputs
        )
        self.qtgui_time_sink_x_0.set_update_time(0.10)
        self.qtgui_time_sink_x_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_0.set_y_label('slice', "")

        self.qtgui_time_sink_x_0.enable_tags(-1, True)
        self.qtgui_time_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_0.enable_autoscale(False)
        self.qtgui_time_sink_x_0.enable_grid(False)
        self.qtgui_time_sink_x_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_0.enable_control_panel(False)

        if not True:
          self.qtgui_time_sink_x_0.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "green", "black", "cyan",
                  "magenta", "yellow", "dark red", "dark green", "blue"]
        styles = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        markers = [-1, -1, -1, -1, -1,
                   -1, -1, -1, -1, -1]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]

        for i in xrange(1):
            if len(labels[i]) == 0:
                self.qtgui_time_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_time_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_0_win = sip.wrapinstance(self.qtgui_time_sink_x_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_time_sink_x_0_win)
        self.qtgui_const_sink_x_5 = qtgui.const_sink_c(
        	1024, #size
        	'tx_rrc', #name
        	1 #number of inputs
        )
        self.qtgui_const_sink_x_5.set_update_time(0.10)
        self.qtgui_const_sink_x_5.set_y_axis(-2, 2)
        self.qtgui_const_sink_x_5.set_x_axis(-2, 2)
        self.qtgui_const_sink_x_5.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_5.enable_autoscale(False)
        self.qtgui_const_sink_x_5.enable_grid(False)
        self.qtgui_const_sink_x_5.enable_axis_labels(True)

        if not True:
          self.qtgui_const_sink_x_5.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "red", "red", "red",
                  "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        for i in xrange(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_5.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_5.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_5.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_5.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_5.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_5.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_5.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_5_win = sip.wrapinstance(self.qtgui_const_sink_x_5.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_const_sink_x_5_win)
        self.qtgui_const_sink_x_3 = qtgui.const_sink_c(
        	1024, #size
        	'qpsk', #name
        	1 #number of inputs
        )
        self.qtgui_const_sink_x_3.set_update_time(0.10)
        self.qtgui_const_sink_x_3.set_y_axis(-2, 2)
        self.qtgui_const_sink_x_3.set_x_axis(-2, 2)
        self.qtgui_const_sink_x_3.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_3.enable_autoscale(False)
        self.qtgui_const_sink_x_3.enable_grid(False)
        self.qtgui_const_sink_x_3.enable_axis_labels(True)

        if not True:
          self.qtgui_const_sink_x_3.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "red", "red", "red",
                  "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        for i in xrange(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_3.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_3.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_3.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_3.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_3.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_3.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_3.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_3_win = sip.wrapinstance(self.qtgui_const_sink_x_3.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_const_sink_x_3_win)
        self.qtgui_const_sink_x_1 = qtgui.const_sink_c(
        	1024, #size
        	'poly_sync', #name
        	1 #number of inputs
        )
        self.qtgui_const_sink_x_1.set_update_time(0.10)
        self.qtgui_const_sink_x_1.set_y_axis(-2, 2)
        self.qtgui_const_sink_x_1.set_x_axis(-2, 2)
        self.qtgui_const_sink_x_1.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_1.enable_autoscale(False)
        self.qtgui_const_sink_x_1.enable_grid(False)
        self.qtgui_const_sink_x_1.enable_axis_labels(True)

        if not True:
          self.qtgui_const_sink_x_1.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "red", "red", "red",
                  "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        for i in xrange(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_1.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_1.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_1.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_1.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_1.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_1.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_1.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_1_win = sip.wrapinstance(self.qtgui_const_sink_x_1.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_const_sink_x_1_win)
        self.qtgui_const_sink_x_0_0 = qtgui.const_sink_c(
        	840-84, #size
        	'costas', #name
        	1 #number of inputs
        )
        self.qtgui_const_sink_x_0_0.set_update_time(0.10)
        self.qtgui_const_sink_x_0_0.set_y_axis(-2, 2)
        self.qtgui_const_sink_x_0_0.set_x_axis(-2, 2)
        self.qtgui_const_sink_x_0_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_0_0.enable_autoscale(False)
        self.qtgui_const_sink_x_0_0.enable_grid(False)
        self.qtgui_const_sink_x_0_0.enable_axis_labels(True)

        if not True:
          self.qtgui_const_sink_x_0_0.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "red", "red", "red",
                  "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        for i in xrange(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_0_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_0_0.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_0_0.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_0_0.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_0_0.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_0_0.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_0_0.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_0_0_win = sip.wrapinstance(self.qtgui_const_sink_x_0_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_const_sink_x_0_0_win)
        self.qtgui_const_sink_x_0 = qtgui.const_sink_c(
        	1024, #size
        	'rm_pilot', #name
        	1 #number of inputs
        )
        self.qtgui_const_sink_x_0.set_update_time(0.10)
        self.qtgui_const_sink_x_0.set_y_axis(-2, 2)
        self.qtgui_const_sink_x_0.set_x_axis(-2, 2)
        self.qtgui_const_sink_x_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, "")
        self.qtgui_const_sink_x_0.enable_autoscale(False)
        self.qtgui_const_sink_x_0.enable_grid(False)
        self.qtgui_const_sink_x_0.enable_axis_labels(True)

        if not True:
          self.qtgui_const_sink_x_0.disable_legend()

        labels = ['', '', '', '', '',
                  '', '', '', '', '']
        widths = [1, 1, 1, 1, 1,
                  1, 1, 1, 1, 1]
        colors = ["blue", "red", "red", "red", "red",
                  "red", "red", "red", "red", "red"]
        styles = [0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0]
        markers = [0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0]
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
                  1.0, 1.0, 1.0, 1.0, 1.0]
        for i in xrange(1):
            if len(labels[i]) == 0:
                self.qtgui_const_sink_x_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_const_sink_x_0.set_line_label(i, labels[i])
            self.qtgui_const_sink_x_0.set_line_width(i, widths[i])
            self.qtgui_const_sink_x_0.set_line_color(i, colors[i])
            self.qtgui_const_sink_x_0.set_line_style(i, styles[i])
            self.qtgui_const_sink_x_0.set_line_marker(i, markers[i])
            self.qtgui_const_sink_x_0.set_line_alpha(i, alphas[i])

        self._qtgui_const_sink_x_0_win = sip.wrapinstance(self.qtgui_const_sink_x_0.pyqwidget(), Qt.QWidget)
        self.top_grid_layout.addWidget(self._qtgui_const_sink_x_0_win)
        self.my_preamble_pilot_remove_pilot_0 = my_preamble_pilot.remove_pilot(frame_width_with_cc)
        self.my_preamble_pilot_my_preamble_detector_0 = my_preamble_pilot.my_preamble_detector(frame_width_with_pilot)
        self.my_preamble_pilot_add_preamble_pilot_0 = my_preamble_pilot.add_preamble_pilot(frame_width_with_cc)
        self.mapper_preamble_sync_demapper_0 = mapper.preamble_sync_demapper(frame_width_with_cc, (pream), mapper.QPSK, ([0,1,3,2]), 1, 3, False)
        self.mapper_preamble_insert_bb_0 = mapper.preamble_insert_bb(frame_width_with_cc, (pream))
        self.mapper_prbs_source_b_0 = mapper.prbs_source_b("PRBS31", frame_width-len(pream))
        self.mapper_my_prbs_sink_b_0 = mapper.my_prbs_sink_b("PRBS31", frame_width-len(pream), False, 'simulation poly siso cc')
        self.mapper_mapper_0 = mapper.mapper(mapper.QPSK, ([0,1,3,2]))
        self.fec_extended_encoder_0 = fec.extended_encoder(encoder_obj_list=enc, threading='capillary', puncpat='11')
        self.fec_extended_decoder_0 = fec.extended_decoder(decoder_obj_list=dec, threading='capillary', ann=None, puncpat='11', integration_period=10000)
        self.digital_pfb_clock_sync_xxx_0_0 = digital.pfb_clock_sync_ccf(sps, 6.28/100.0, (rrc_taps), nfilts, nfilts/2, 0.5, 1)
        self.digital_costas_loop_cc_0_0 = digital.costas_loop_cc(6.28/100.0, 4, False)
        self.digital_correlate_and_sync_cc_0_0_0 = digital.correlate_and_sync_cc(([1 , -1 , -1 , 1 , 1 , -1 , -1 , -1 , -1 , 1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 , -1 , 1 , 1 , 1 , -1 , 1 , -1 , -1 , -1 , 1 , 1 , 1 , 1 , 1 , -1 , 1 , -1 , -1 , 1 , 1 , 1 , -1 , -1 , -1 , -1 , 1 , 1 , -1 , 1 , 1 , 1 , 1 , 1 , 1 , -1 , -1 , 1 , -1 , -1 , 1 , 1 , 1 , -1 , 1 , 1 , 1 , 1]), (1, ), 1)
        self.digital_corr_est_cc_0_0 = digital.corr_est_cc((preamble), sps, mark_delay, 0.999)
        self.channels_channel_model_0 = channels.channel_model(
        	noise_voltage=(10**(-SNR/10.0))*np.sqrt(samp_per_sym),
        	frequency_offset=cfo,
        	epsilon=1.0+sro,
        	taps=([1]),
        	noise_seed=0,
        	block_tags=False
        )
        self.blocks_throttle_0 = blocks.throttle(gr.sizeof_char*1, samp_rate,True)
        self.blocks_multiply_by_tag_value_cc_0_0 = blocks.multiply_by_tag_value_cc("amp_est", 1)
        self.blocks_moving_average_xx_0 = blocks.moving_average_ff(64, 0.5, 4000)
        self.blocks_delay_0 = blocks.delay(gr.sizeof_float*1, 2)
        self.blocks_complex_to_mag_squared_0 = blocks.complex_to_mag_squared(1)
        self.blocks_char_to_float_0 = blocks.char_to_float(1, 1)

        ##################################################
        # Connections
        ##################################################
        self.connect((self.blocks_char_to_float_0, 0), (self.qtgui_time_sink_x_0, 0))
        self.connect((self.blocks_complex_to_mag_squared_0, 0), (self.blocks_delay_0, 0))
        self.connect((self.blocks_delay_0, 0), (self.blocks_moving_average_xx_0, 0))
        self.connect((self.blocks_moving_average_xx_0, 0), (self.my_preamble_pilot_my_preamble_detector_0, 2))
        self.connect((self.blocks_multiply_by_tag_value_cc_0_0, 0), (self.digital_pfb_clock_sync_xxx_0_0, 0))
        self.connect((self.blocks_throttle_0, 0), (self.fec_extended_encoder_0, 0))
        self.connect((self.channels_channel_model_0, 0), (self.digital_corr_est_cc_0_0, 0))
        self.connect((self.digital_corr_est_cc_0_0, 0), (self.blocks_multiply_by_tag_value_cc_0_0, 0))
        self.connect((self.digital_correlate_and_sync_cc_0_0_0, 1), (self.blocks_complex_to_mag_squared_0, 0))
        self.connect((self.digital_correlate_and_sync_cc_0_0_0, 1), (self.my_preamble_pilot_my_preamble_detector_0, 1))
        self.connect((self.digital_correlate_and_sync_cc_0_0_0, 0), (self.my_preamble_pilot_my_preamble_detector_0, 0))
        self.connect((self.digital_costas_loop_cc_0_0, 0), (self.digital_correlate_and_sync_cc_0_0_0, 0))
        self.connect((self.digital_costas_loop_cc_0_0, 0), (self.qtgui_const_sink_x_0_0, 0))
        self.connect((self.digital_costas_loop_cc_0_0, 0), (self.qtgui_time_sink_x_2_1_0, 0))
        self.connect((self.digital_pfb_clock_sync_xxx_0_0, 0), (self.digital_costas_loop_cc_0_0, 0))
        self.connect((self.digital_pfb_clock_sync_xxx_0_0, 0), (self.qtgui_const_sink_x_1, 0))
        self.connect((self.digital_pfb_clock_sync_xxx_0_0, 0), (self.qtgui_time_sink_x_2_1, 0))
        self.connect((self.fec_extended_decoder_0, 0), (self.blocks_char_to_float_0, 0))
        self.connect((self.fec_extended_decoder_0, 0), (self.mapper_my_prbs_sink_b_0, 0))
        self.connect((self.fec_extended_encoder_0, 0), (self.mapper_preamble_insert_bb_0, 0))
        self.connect((self.mapper_mapper_0, 0), (self.my_preamble_pilot_add_preamble_pilot_0, 0))
        self.connect((self.mapper_mapper_0, 0), (self.qtgui_const_sink_x_3, 0))
        self.connect((self.mapper_mapper_0, 0), (self.qtgui_time_sink_x_1, 0))
        self.connect((self.mapper_prbs_source_b_0, 0), (self.blocks_throttle_0, 0))
        self.connect((self.mapper_preamble_insert_bb_0, 0), (self.mapper_mapper_0, 0))
        self.connect((self.mapper_preamble_sync_demapper_0, 0), (self.fec_extended_decoder_0, 0))
        self.connect((self.my_preamble_pilot_add_preamble_pilot_0, 0), (self.root_raised_cosine_filter_0, 0))
        self.connect((self.my_preamble_pilot_my_preamble_detector_0, 0), (self.my_preamble_pilot_remove_pilot_0, 0))
        self.connect((self.my_preamble_pilot_my_preamble_detector_0, 0), (self.qtgui_time_sink_x_2_1_0_0, 0))
        self.connect((self.my_preamble_pilot_remove_pilot_0, 0), (self.mapper_preamble_sync_demapper_0, 0))
        self.connect((self.my_preamble_pilot_remove_pilot_0, 0), (self.qtgui_const_sink_x_0, 0))
        self.connect((self.my_preamble_pilot_remove_pilot_0, 0), (self.qtgui_time_sink_x_1_0_0, 0))
        self.connect((self.root_raised_cosine_filter_0, 0), (self.channels_channel_model_0, 0))
        self.connect((self.root_raised_cosine_filter_0, 0), (self.qtgui_const_sink_x_5, 0))

    def closeEvent(self, event):
        self.settings = Qt.QSettings("GNU Radio", "top_block")
        self.settings.setValue("geometry", self.saveGeometry())
        event.accept()

    def get_eb(self):
        return self.eb

    def set_eb(self, eb):
        self.eb = eb
        self.set_rrc_taps(firdes.root_raised_cosine(self.nfilts, self.nfilts, 1.0/float(self.sps), self.eb, 5*self.sps*self.nfilts))
        self.set_matched_filter(firdes.root_raised_cosine(self.nfilts, self.nfilts, 1, self.eb, int(11*self.sps*self.nfilts)))

    def get_sps(self):
        return self.sps

    def set_sps(self, sps):
        self.sps = sps
        self.set_rrc_taps(firdes.root_raised_cosine(self.nfilts, self.nfilts, 1.0/float(self.sps), self.eb, 5*self.sps*self.nfilts))
        self.set_mark_delay(self.mark_delays[self.sps])
        self.set_matched_filter(firdes.root_raised_cosine(self.nfilts, self.nfilts, 1, self.eb, int(11*self.sps*self.nfilts)))

    def get_nfilts(self):
        return self.nfilts

    def set_nfilts(self, nfilts):
        self.nfilts = nfilts
        self.set_rrc_taps(firdes.root_raised_cosine(self.nfilts, self.nfilts, 1.0/float(self.sps), self.eb, 5*self.sps*self.nfilts))
        self.set_matched_filter(firdes.root_raised_cosine(self.nfilts, self.nfilts, 1, self.eb, int(11*self.sps*self.nfilts)))

    def get_rrc_taps(self):
        return self.rrc_taps

    def set_rrc_taps(self, rrc_taps):
        self.rrc_taps = rrc_taps
        self.set_filt_delay(1+(len(self.rrc_taps)-1)/2)
        self.digital_pfb_clock_sync_xxx_0_0.update_taps((self.rrc_taps))

    def get_mark_delays(self):
        return self.mark_delays

    def set_mark_delays(self, mark_delays):
        self.mark_delays = mark_delays
        self.set_mark_delay(self.mark_delays[self.sps])

    def get_sro(self):
        return self.sro

    def set_sro(self, sro):
        self.sro = sro
        self.channels_channel_model_0.set_timing_offset(1.0+self.sro)

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.samp_rate, self.samp_rate/self.samp_per_sym, 0.35, 11))
        self.qtgui_time_sink_x_2_1_0_0.set_samp_rate(self.samp_rate)
        self.qtgui_time_sink_x_2_1_0.set_samp_rate(self.samp_rate)
        self.qtgui_time_sink_x_2_1.set_samp_rate(self.samp_rate)
        self.qtgui_time_sink_x_1_0_0.set_samp_rate(self.samp_rate)
        self.qtgui_time_sink_x_1.set_samp_rate(self.samp_rate)
        self.qtgui_time_sink_x_0.set_samp_rate(self.samp_rate)
        self.blocks_throttle_0.set_sample_rate(self.samp_rate)

    def get_samp_per_sym(self):
        return self.samp_per_sym

    def set_samp_per_sym(self, samp_per_sym):
        self.samp_per_sym = samp_per_sym
        self.root_raised_cosine_filter_0.set_taps(firdes.root_raised_cosine(1, self.samp_rate, self.samp_rate/self.samp_per_sym, 0.35, 11))
        self.channels_channel_model_0.set_noise_voltage((10**(-self.SNR/10.0))*np.sqrt(self.samp_per_sym))

    def get_preamble(self):
        return self.preamble

    def set_preamble(self, preamble):
        self.preamble = preamble

    def get_pream(self):
        return self.pream

    def set_pream(self, pream):
        self.pream = pream
        self.mapper_preamble_insert_bb_0.mapper.set_preamble((self.pream))

    def get_matched_filter(self):
        return self.matched_filter

    def set_matched_filter(self, matched_filter):
        self.matched_filter = matched_filter

    def get_mark_delay(self):
        return self.mark_delay

    def set_mark_delay(self, mark_delay):
        self.mark_delay = mark_delay
        self.digital_corr_est_cc_0_0.set_mark_delay(self.mark_delay)

    def get_gold_sequence(self):
        return self.gold_sequence

    def set_gold_sequence(self, gold_sequence):
        self.gold_sequence = gold_sequence

    def get_frame_width_with_pilot(self):
        return self.frame_width_with_pilot

    def set_frame_width_with_pilot(self, frame_width_with_pilot):
        self.frame_width_with_pilot = frame_width_with_pilot

    def get_frame_width_with_cc(self):
        return self.frame_width_with_cc

    def set_frame_width_with_cc(self, frame_width_with_cc):
        self.frame_width_with_cc = frame_width_with_cc
        self.mapper_preamble_insert_bb_0.mapper.set_width(self.frame_width_with_cc)

    def get_frame_width(self):
        return self.frame_width

    def set_frame_width(self, frame_width):
        self.frame_width = frame_width

    def get_filt_delay(self):
        return self.filt_delay

    def set_filt_delay(self, filt_delay):
        self.filt_delay = filt_delay

    def get_enc(self):
        return self.enc

    def set_enc(self, enc):
        self.enc = enc

    def get_dec(self):
        return self.dec

    def set_dec(self, dec):
        self.dec = dec

    def get_cfo(self):
        return self.cfo

    def set_cfo(self, cfo):
        self.cfo = cfo
        self.channels_channel_model_0.set_frequency_offset(self.cfo)

    def get_SNR(self):
        return self.SNR

    def set_SNR(self, SNR):
        self.SNR = SNR
        Qt.QMetaObject.invokeMethod(self._SNR_line_edit, "setText", Qt.Q_ARG("QString", eng_notation.num_to_str(self.SNR)))
        self.channels_channel_model_0.set_noise_voltage((10**(-self.SNR/10.0))*np.sqrt(self.samp_per_sym))


def argument_parser():
    parser = OptionParser(usage="%prog: [options]", option_class=eng_option)
    parser.add_option(
        "", "--eb", dest="eb", type="eng_float", default=eng_notation.num_to_str(0.35),
        help="Set Filter Rolloff [default=%default]")
    parser.add_option(
        "", "--sps", dest="sps", type="intx", default=2,
        help="Set Samples per Symbol [default=%default]")
    return parser


def main(top_block_cls=top_block, options=None):
    if options is None:
        options, _ = argument_parser().parse_args()

    from distutils.version import StrictVersion
    if StrictVersion(Qt.qVersion()) >= StrictVersion("4.5.0"):
        style = gr.prefs().get_string('qtgui', 'style', 'raster')
        Qt.QApplication.setGraphicsSystem(style)
    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls(eb=options.eb, sps=options.sps)
    tb.start()
    tb.show()

    def quitting():
        tb.stop()
        tb.wait()
    qapp.connect(qapp, Qt.SIGNAL("aboutToQuit()"), quitting)
    qapp.exec_()


if __name__ == '__main__':
    main()
