function [Sym_pilot]=add_pilot_siso(Sym,Nfft,complex_gold,interval,all_ofdm)
%sum OFDM
Sym_pilot=zeros(Nfft,all_ofdm);
idx=1;
ip=0;
%add
while idx<=all_ofdm
    if mod(idx,interval)==1
        Sym_pilot(:,idx)=[complex_gold];
        idx=idx+1;
        ip=ip+1;
    else
        Sym_pilot(:,idx)=Sym(:,idx-ip);
        idx=idx+1;
    end
end