function x_sync = sync_two_signals( x_resampled,x_training_wave,idx )
% sync_two_signals( x_resampled,x_training_wave,idx )
% x_resampled���յ����ź�
% x_training_wave���÷��͵��ź�
% idx��Ҫ��ͬ���ϵĵڼ��Ρ�idx = 1,2,3,...

[hicorrI,lagsiI]=xcorr(x_resampled,x_training_wave);
[~,offsetindex]=max((hicorrI));
% offsetindex
for n = 2 : idx
    % figure;plot(lagsiI,abs(hicorrI));
    hicorrI(offsetindex) = -inf;
    [~,offsetindex]=max(hicorrI);
end
% offsetindex
h=1;    
x_sync=x_resampled(lagsiI(offsetindex)+h:lagsiI(offsetindex)+length(x_training_wave)+h-1);

end
