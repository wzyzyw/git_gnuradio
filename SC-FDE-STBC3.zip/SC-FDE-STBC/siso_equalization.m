function R_Data=siso_equalization(H_est,input_data,snr,flag)
[carrier_count,NumLoop]=size(input_data);
R_Data = zeros(carrier_count,NumLoop);
for ii= 1:NumLoop
    if flag==1
        W=1./H_est(:,ii);
    end
    if flag==2
        W=conj(H_est(:,ii))./(abs(H_est(:,ii)).^2+ones(carrier_count,1)*1/snr);
    end
    R_Data(:,ii)=input_data(:,ii).*W;
end
%     for jj = 1:2:NumLoop-1
%         tmp_y=[y(:,jj);conj(y(:,jj+1))];
%         tmp_H=[H1(:,:,jj),H2(:,:,jj);conj(H2(:,:,jj)),-conj(H1(:,:,jj))];
%         tmp1=abs(diag(H1(:,:,jj))).^2;
%         tmp2=abs(diag(H2(:,:,jj))).^2;
%         tmp_power=diag(tmp1+tmp2);
%         power=[tmp_power,zeros(size(tmp_power));zeros(size(tmp_power)),tmp_power];
%         tmp_r=inv(power)*(tmp_H'*tmp_y); 
%         R_Data(:,jj:jj+1)=reshape(tmp_r,carrier_count,2);
%     end
