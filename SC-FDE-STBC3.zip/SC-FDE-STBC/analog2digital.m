function reconstructed_digital_signal=analog2digital(input,fc,t,rrc,span,Fs,sps,fltDelay)
%�±�Ƶ
% filtered_reconstructed_digital_signal=input.*exp(-1j*2*pi*fc*t);
noised_recieved_signal = input.*cos(2*pi*fc*t) - 1i*input.*sin(2*pi*fc*t);
% noised_recieved_signal=input;
%ƥ���˲�
% filtered_reconstructed_digital_signal = step(rrc, [noised_recieved_signal; zeros(fltDelay*Fs,1)]); 
filtered_reconstructed_digital_signal=filter(rrc, [noised_recieved_signal; zeros(fltDelay*Fs,1)]);
%�²���
reconstructed_digital_signal = downsample(filtered_reconstructed_digital_signal, sps);
reconstructed_digital_signal = reconstructed_digital_signal(span/2+1:end); % Correct for propagation delay by removing filter transients