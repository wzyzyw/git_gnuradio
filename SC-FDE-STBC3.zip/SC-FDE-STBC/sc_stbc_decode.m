function R_Data=sc_stbc_decode(H1_est,H2_est,input_data,snr,flag)
[carrier_count,NumLoop]=size(input_data);
R_Data = zeros(carrier_count,NumLoop);
y=input_data;
for ii= 1:carrier_count
    for jj = 1:2:NumLoop-1
        tmp_y=[y(ii,jj);conj(y(ii,jj+1))];
        tmp_H=[H1_est(ii,jj),H2_est(ii,jj);conj(H2_est(ii,jj)),-conj(H1_est(ii,jj))];
        tmp_H_power=abs(H1_est(ii,jj))^2+abs(H2_est(ii,jj))^2;
        if flag==1
            R_Data(ii,jj:jj+1)=tmp_H'*tmp_y./(tmp_H_power); 
        end
        if flag==2
            R_Data(ii,jj:jj+1)=tmp_H'*tmp_y./(tmp_H_power+1/snr); 
        end
%         R_Data(ii,jj:jj+1)=pinv(tmp_H)*tmp_y;
    end
end
%     for jj = 1:2:NumLoop-1
%         tmp_y=[y(:,jj);conj(y(:,jj+1))];
%         tmp_H=[H1(:,:,jj),H2(:,:,jj);conj(H2(:,:,jj)),-conj(H1(:,:,jj))];
%         tmp1=abs(diag(H1(:,:,jj))).^2;
%         tmp2=abs(diag(H2(:,:,jj))).^2;
%         tmp_power=diag(tmp1+tmp2);
%         power=[tmp_power,zeros(size(tmp_power));zeros(size(tmp_power)),tmp_power];
%         tmp_r=inv(power)*(tmp_H'*tmp_y); 
%         R_Data(:,jj:jj+1)=reshape(tmp_r,carrier_count,2);
%     end
