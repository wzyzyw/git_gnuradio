
clear all; close all;
fd = 1;
ts = 1/9.6e3;
M=4;
hMod = comm.QPSKModulator(0);
% s=doppler('BiGaussian', 'NormalizedStandardDeviations', [.8 .75], 'NormalizedCenterFrequencies', [-.8 0], 'PowerGains', [.6 .6]);



% hLMChan = comm.RayleighChannel( ...
%     'SampleRate',          1/ts, ...
%     'PathDelays',          [0 0.002], ...
%     'AveragePathGains',    [0 0], ...
%     'MaximumDopplerShift', fd, ...
%     'DopplerSpectrum',     doppler('Gaussian',(1.5/2)/fd), ...
%     'RandomStream',        'mt19937ar with seed', ...
%     'Seed',                9999, ...
%     'PathGainsOutputPort', true, ...
%     'Visualization',       'Impulse response');
% 
% Nsamp_f = 1e3;      % Number of samples per frame
% Nframes = 10;       % Number of frames
% for iFrames = 1:Nframes
%    inputSig = step(hMod, randi([0 M-1], Nsamp_f, 1));
%    step(hLMChan, inputSig);
% end
% 
% release(hLMChan);
% hLMChan.Visualization = 'Doppler spectrum';
% Nsamp_f = 2e6;      % Number of samples per frame
% Nframes = 80;       % Number of frames
% for iFrames = 1:Nframes
%    inputSig = step(hMod, randi([0 M-1], Nsamp_f, 1));
%    step(hLMChan, inputSig);
% end


fd = 1;
[hdchan,chanprofile] = stdchan(ts, fd, 'iturHFMD');%ÿ�ε����ŵ����Ƕ�����
%If set to 1, the complex path gain vector is stored as the channel filter function processes the signal. 
%The default value is 0.
hdchan.StorePathGains = 1;
%If 1, each call to filter resets the state of chan before filtering. 
%If 0, the fading process maintains continuity from one call to the next.
hdchan.ResetBeforeFiltering = 0;
hdchan.NormalizePathGains = 1;

Nsamp = 2e6;                    % Total number of channel samples
Nsamp_f = 2000;                 % Number of samples per frame
% Nframes = Nsamp/Nsamp_f;        % Number of frames
Nframes=1;
s = zeros(Nsamp, 1);  y = zeros(Nsamp, 2);h1=zeros(Nsamp,1);h2=zeros(Nsamp,1);
for iFrames = 1:Nframes
    inputSig = step(hMod, randi([0 M-1], Nsamp_f, 1));%ͨ�Ź�����ʹ��step�൱���õ��ƶ�����������ݵ��ƣ����鿴help ���ƶ���
    s( (1:Nsamp_f) + (iFrames-1)*Nsamp_f ) = filter(hdchan, inputSig);%step��filter�������˲������ŵ�����
    h1((1:Nsamp_f) + (iFrames-1)*Nsamp_f)=fft(s( (1:Nsamp_f) + (iFrames-1)*Nsamp_f ))./fft(inputSig);
%     ans=filter(hdchan, [inputSig;zeros(100,1)]);
%     ans2=hdchan.PathGains;
    y( (1:Nsamp_f) + (iFrames-1)*Nsamp_f, :) = hdchan.PathGains;%ITU �ŵ�������·���� ���������У����������˲����ֻ��һ�У����ӡ�
    h2((1:Nsamp_f) + (iFrames-1)*Nsamp_f)=fft(y( (1:Nsamp_f) + (iFrames-1)*Nsamp_f, 1))+fft(y( (1:Nsamp_f) + (iFrames-1)*Nsamp_f, 2));
    a=hdchan.PathGains;
    g=
    
end
sigmaGaussian = 30/2;%HD�ŵ���Ƶ��30Hz���Ǳ�׼�������
f = -1/(2*ts) : 0.1 : 1/(2*ts);
Sd = 0.5 * 1/sqrt(2*pi*(sigmaGaussian*fd)^2) ...
         * exp(-f.^2/(2*(sigmaGaussian*fd)^2));%��˹������Ƶ��
figure;

hs1 = subplot(2, 1, 1); hold on;
pwelch(y(:,1), hamming(Nsamp/100), [], [], 1/ts, 'centered');%�ŵ������׹���
axis([-0.1 0.1 -80 0]);

plot(hs1, f(Sd>0)/1e3, 10*log10(Sd(Sd>0)), 'k--');
legend('Simulation', 'Theory');
title('Welch Power Spectral Density Estimate for Path 1');

hs2 = subplot(2, 1, 2); hold on;
pwelch(y(:,2), hamming(Nsamp/100), [], [], 1/ts, 'centered');
axis([-0.1 0.1 -80 0]);

plot(hs2, f(Sd>0)/1e3, 10*log10(Sd(Sd>0)), 'k--');
legend('Simulation', 'Theory');
title('Welch Power Spectral Density Estimate for Path 2');


% qpskMod = comm.QPSKModulator(0); % QPSK modulator object
% chanLM = stdchan(ts, fd,'iturHFLM');
% %���������ΪԴ
% chanLM.RandomStream = 'mt19937ar with seed';
% chanLM.Seed = 9999;
% chanLM.PathGainsOutputPort = true;
% %ָ��Ҫ��ʾΪOff |֮һ��ͨ�����ӻ����� Impulse response | Frequency response | Impulse and frequency responses | Doppler spectrum 
% %�����Ե�Ĭ��ֵΪOff
% chanLM.Visualization = 'Impulse response';

