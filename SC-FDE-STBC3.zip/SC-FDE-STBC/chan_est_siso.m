function [H_est,Data]=chan_est_siso(data_pilot,interval,complex_gold,Nps)
idx=1;
pilot_loc=[];
data_loc=[];
while idx<=size(data_pilot,2)   
    if mod(idx,interval)==1
        pilot_loc = [pilot_loc idx]; 
        idx=idx+1;
    else
        data_loc=[data_loc,idx];
        idx=idx+1;
    end
end
rx_pilot=data_pilot(:,pilot_loc);
Data=data_pilot(:,data_loc);%�ҵ�һ��ofdm���������ݷ���
len=size(rx_pilot,2);
Complex_gold=fft(complex_gold);
gold_tmp=kron(ones(1,len),Complex_gold);
H_tmp=rx_pilot./gold_tmp;
%interpolate
% % Nfft=size(data_pilot,1);
% % % H1_tmp=H1_tmp(1,:);
% % % H2_tmp=H2_tmp(1,:);
% % H1_tmp=mean(H1_tmp);
% % H2_tmp=mean(H2_tmp);
% % inter_index=1:size(data_pilot,2);
% % H1_est=interp1(pilot_loc1,H1_tmp,inter_index,'linear');
% % H2_est=interp1(pilot_loc2,H2_tmp,inter_index,'linear');
% % H1_est=H1_est(data_loc);
% % H1_est=kron(H1_est,ones(Nfft,1));
% % H2_est=H2_est(data_loc);
% % H2_est=kron(H2_est,ones(Nfft,1));
% switch method
%     case 'equal' 
        H_est=kron(H_tmp,ones(1,Nps));     
%     case 'linear'
%         
% end
