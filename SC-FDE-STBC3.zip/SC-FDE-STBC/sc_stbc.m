function [encode_data1,encode_data2]=sc_stbc(data,Nfft,frame_num)%data������
carrier_count=Nfft;
Sym=data;
NumLoop=frame_num;
encode_data1 = zeros(carrier_count,NumLoop);
encode_data2 = zeros(carrier_count,NumLoop);
SymFFTtmp = reshape(Sym,carrier_count,NumLoop);
%ż����ȡ����
% SymFFTtmp(:,2:2:end)=conj(SymFFTtmp(:,2:2:end));
%sc-stbc
for ii=1:2:NumLoop  %alamouti���벢����ת��
    encode_data1(:,ii)=SymFFTtmp(:,ii);
    encode_data2(:,ii)=SymFFTtmp(:,ii+1);
    tmp=flipud(SymFFTtmp(2:end,ii+1));
    tmp=[SymFFTtmp(1,ii+1);tmp];
    encode_data1(:,ii+1)=-1*conj(tmp);
    tmp=flipud(SymFFTtmp(2:end,ii)); 
    tmp=[SymFFTtmp(1,ii);tmp];
    encode_data2(:,ii+1)=conj(tmp);
end 
end