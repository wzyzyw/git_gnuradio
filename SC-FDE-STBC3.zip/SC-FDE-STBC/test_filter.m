clear all;
x1=[-2,0,1,-1,3];
h=[1 2 0 -1];
% h_2=[h,zeros(1,7)];
y1=conv(x1,h);
y2=filter(h,1,x1);
x1_1=[x1(length(h)-1:end),x1];
x1_2=[x1,zeros(1,3)];
x1_3=[x1_1,zeros(1,3)];
y3=conv(x1_1,h);
y4=cconv(x1,h,5);
y5=filter(h,1,x1_2);
y6=filter(h,1,x1_3);
y7=filter(h,1,x1_1);
y3=y3.';
y6=y6.';

