clear all; close all;
Fs=4e3;%Hz
ts=1/Fs;
fc=10e6;%Hz
sps=4;
Rb=2e3;%2000bits/s
Bw=3000;%Hz
Nfft=64;  Ng=16;  Nofdm=Nfft+Ng;  
% frame_len=3*Nofdm;%һ֡����3��ofdm����
frame_num=40;
Nd=Nfft; % Pilot spacing, Numbers of pilots and data per OFDM symbol
Nsym=Nd*frame_num;%�ܵ�qpsk������
%pilot parameter
pilot_len=Nfft;
bps=2; M=2^bps; % Number of bits per (modulated) symbol
hMod = comm.QPSKModulator('BitInput',true);%default:pi/4,gray map
hDemod = comm.QPSKDemodulator('BitOutput',true);
%rrc design
beta=0.2;
span=4;
L = sps*span + 1;%rrc order
% rrc=comm.RaisedCosineTransmitFilter('RolloffFactor',beta,'FilterSpanInSymbols',span,'OutputSamplesPerSymbol',sps/sps);
shape = 'Raised Cosine';
% Specifications of the raised cosine filter with given order in symbols
rcosSpec = fdesign.pulseshaping(sps, shape, 'Nsym,beta', span, beta);
rcosFlt = design(rcosSpec);
rcosFlt.Numerator = rcosFlt.Numerator / max(rcosFlt.Numerator);
TX_FILT = comm.RaisedCosineTransmitFilter;
TX_FILT.FilterSpanInSymbols=4;
TX_FILT.OutputSamplesPerSymbol=4;
RX_FILT = comm.RaisedCosineReceiveFilter;
RX_FILT.FilterSpanInSymbols=4;
RX_FILT.InputSamplesPerSymbol=4;
% pilot_symbol=chu_sequence(Np);%ÿ��ofdm���Ŷ�����ͬ��pilot
% % pilot_symbol=gold_sequence(Np);
% rand('seed',10); 
msgint=randint(bps*Nsym,1); %��������Դ
Data=step(hMod,msgint);
conse_msgint=comm.ConstellationDiagram('Title','Input bits Consetellation');
conse_msgint.SymbolsToDisplay=length(Data);
step(conse_msgint,Data);
%alamouti encode
[encode1,encode2]=sc_stbc(Data,Nd,frame_num);
%add UW
Nps=4; %ʵ�ʲ��뵼Ƶʱ�������ļ��������ȷ����Ƶλ��
Np=frame_num/Nps;%��β���ǵ�Ƶ���������һ�����ŵĲ�ֵ
interval=Nps+2;
all_ofdm=frame_num+Np*2;
complex_gold=gold_sequence(pilot_len);
% complex_gold=chu_sequence(pilot_len);
[encode1_pilot,encode2_pilot]=add_pilot(encode1,encode2,Nfft,complex_gold,interval,all_ofdm);
% encode1_pilot=encode1
% encode2_pilot=encode2;
%add (CP)
tx1_tmp = [encode1_pilot(Nfft-Ng+1:Nfft,:);encode1_pilot];
tx2_tmp = [encode2_pilot(Nfft-Ng+1:Nfft,:);encode2_pilot];
%��������˲�
%P->S
tx1_tmp=tx1_tmp(:);
tx2_tmp=tx2_tmp(:);
% tx1=filter(rcosFlt, upsample([tx1_tmp; zeros(span/2,1)], sps));
tx1=step(TX_FILT,upsample([tx1_tmp; zeros(span/2,1)], sps));
fltDelay = span / (2*Rb); % Filter group delay, since raised cosine filter is linear phase and symmetric.
tx1=tx1(fltDelay*Fs+1:end);
% tx2=filter(rcosFlt, upsample([tx2_tmp; zeros(span/2,1)], sps));
tx2=step(TX_FILT,upsample([tx2_tmp; zeros(span/2,1)], sps));
tx2=tx2(fltDelay*Fs+1:end);
t = (0: length(tx1) - 1) / Fs;
t=t';
%�ز�
signal1=tx1;
signal2=tx2;
signal1=reshape(signal1,Nofdm,all_ofdm);
signal2=reshape(signal2,Nofdm,all_ofdm);
%channel
[h1,h2]=channel(Nd,all_ofdm,Ng);
SNRs = [0:40];
BERs=zeros(1,length(SNRs));
for i=1:length(SNRs)
   SNR = SNRs(i); 
%    rx=filter(h1,signal1)+filter(h2,signal2);
%    rx=awgn(rx,SNR,'measured');
for idx=1:all_ofdm
    rx_tmp=filter(h1(:,idx),1,tx1(:,idx))+filter(h2(:,idx),1,tx2(:,idx));
%     rx_tmp=filter(h1,tx1(:,idx))+filter(h2,tx2(:,idx));
    rx_tmp=awgn(rx_tmp,SNR,'measured');
    rx=[rx;rx_tmp];
end
   %A-D,ƥ���˲�
%    reconstructed_digital_signal=analog2digital(rx,fc,t,rcosFlt,span,Fs,sps,fltDelay);
     reconstructed_digital_signal=analog2digital(rx,fc,t,RX_FILT,span,Fs,sps,fltDelay);
   %S->P
   rx=reshape(reconstructed_digital_signal,Nofdm,all_ofdm);
   %remove cp
   rx_rcp=rx(Ng+1:Nofdm,:);
   %fft dim=1,���н���fft��dim=2,���н���fft
   Rx=fft(rx_rcp,Nfft,1);
%    figure(4)
%    plot( Rx_rcp,'r*');
%    xlabel('real')
%    ylabel('image')
%    title('����Ƶ���ź�����ͼ');
   %decode
%    H1=h1(Ng+1:end,:);
%    H2=h2(Ng+1:end,:);
   %LS 
   [H1_est,H2_est,Data]=chan_est_block(Rx,interval,complex_gold,Nps);
%    H1_est=fft(h1,Nfft,1);
%    H2_est=fft(h2,Nfft,1);
   rx_data=sc_stbc_decode(H1_est,H2_est,Data);
   rx_data=ifft(rx_data,Nfft,1);
   %P->S
   Rx_data=rx_data(:);
   % �����н����ķ��Ž���qpsk���
   demod_bit=step(hDemod,Rx_data);
   nbits_error=0;
   len=min(length(demod_bit),length(msgint));
   nbits_error=nbits_error+sum(xor(demod_bit(1:len),msgint(1:len)));
   ber=nbits_error/len;
   BERs(i)=ber;
end
figure(1), clf, semilogy(SNRs,BERs);
xlabel('Eb/N0(dB)');
ylabel('BER');
title('BER for QPSK modulation with Alamouti STBC (Rayleigh channel)');
figure(2)
plot( Rx_data,'r*');
xlabel('real')
ylabel('image')
title('�����ź�����ͼ');

