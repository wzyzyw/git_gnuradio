clear all; close all;
Fs=200000;%Hz
ts=1/Fs;
fc=Fs/5;%Hz
sps=10;
Rb=Fs/sps;%2000bits/s
Bw=3000;%Hz
Nfft=128;  Ng=80;  Nofdm=Nfft+Ng;  
% frame_len=3*Nofdm;%һ֡����3��ofdm����
frame_num=40;
Nd=Nfft; % Pilot spacing, Numbers of pilots and data per OFDM symbol
Nsym=Nd*frame_num;%�ܵ�qpsk������
%pilot parameter
pilot_len=Nfft;
bps=2; M=2^bps; % Number of bits per (modulated) symbol
hMod = comm.QPSKModulator('BitInput',true);%default:pi/4,gray map
hDemod = comm.QPSKDemodulator('BitOutput',true);
% pilot_symbol=chu_sequence(Np);%ÿ��ofdm���Ŷ�����ͬ��pilot
% % pilot_symbol=gold_sequence(Np);
% rand('seed',10); 
msgint=randint(bps*Nsym,1); %��������Դ
Data=step(hMod,msgint);
% conse_msgint=comm.ConstellationDiagram('Title','Input bits Consetellation');
% conse_msgint.SymbolsToDisplay=length(Data);
% step(conse_msgint,Data);
%S->P
Sym = reshape(Data,Nd,frame_num);
%add UW
Nps=2; %ʵ�ʲ��뵼Ƶʱ�������ļ��������ȷ����Ƶλ��
Np=frame_num/Nps;%��β���ǵ�Ƶ���������һ�����ŵĲ�ֵ
interval=Nps+1;
all_ofdm=frame_num+Np;
% complex_gold=gold_sequence(pilot_len);
complex_gold=chu_sequence(pilot_len);
[Sym_pilot]=add_pilot_siso(Sym,Nfft,complex_gold,interval,all_ofdm);
%add (CP)
tx = [Sym_pilot(Nfft-Ng+1:Nfft,:);Sym_pilot];

%rrc
beta=0.2;
span=4;
L = sps*span + 1;%rrc order
% rrc=comm.RaisedCosineTransmitFilter('RolloffFactor',beta,'FilterSpanInSymbols',span,'OutputSamplesPerSymbol',sps/sps);
shape = 'Raised Cosine';
% Specifications of the raised cosine filter with given order in symbols
rcosSpec = fdesign.pulseshaping(sps, shape, 'Nsym,beta', span, beta);
rcosFlt = design(rcosSpec);
rcosFlt.Numerator = rcosFlt.Numerator / max(rcosFlt.Numerator);
%pulse shape
tx=tx(:);
signal=filter(rcosFlt, upsample([tx; zeros(span/2,1)], sps));
fltDelay = span / (2*Rb); % Filter group delay, since raised cosine filter is linear phase and symmetric.
signal=signal(fltDelay*Fs+1:end);
t = (0: length(signal) - 1) / Fs;
t=t';
%carrrier
I = real(signal);
Q = imag(signal);
signal = I.*cos(2*pi*fc*t) - Q.*sin(2*pi*fc*t);
signal=reshape(signal,Nofdm*sps,all_ofdm);
%channel
% [h1,h2]=channel(Nd,all_ofdm,Ng);
[h1,h2]=hf_stbc_chan(ts,'iturHFMD');
SNRs = [0:2:30];
BERs=zeros(1,length(SNRs));
for i=1:length(SNRs)
   SNR = SNRs(i); 
%    rx=filter(h1,signal);
% %    rx=signal;
% %    rx=filter(h1(:,1),1,signal);
%    rx=awgn(rx,SNR,'measured');
   
   rx=[];
for idx=1:all_ofdm
%     rx_tmp=filter(h1(:,idx),1,signal(:,idx));
    rx_tmp=filter(h1,signal(:,idx));
%       rx_tmp=tx(:,idx);
    rx_tmp=awgn(rx_tmp,SNR,'measured');
    rx=[rx;rx_tmp];
end
  
  %match filter
   reconstructed_digital_signal=analog2digital(rx,fc,t,rcosFlt,span,Fs,sps,fltDelay);
   %S->P
   rx=reshape(reconstructed_digital_signal,Nofdm,all_ofdm);
   %remove cp
   rx_rcp=rx(Ng+1:Nofdm,:);
   %fft dim=1,���н���fft��dim=2,���н���fft
   Rx=fft(rx_rcp,Nfft,1);
%    figure(4)
%    plot( Rx_rcp,'r*');
%    xlabel('real')
%    ylabel('image')
%    title('����Ƶ���ź�����ͼ');
   %decode
%    H1=h1(Ng+1:end,:);
%    H2=h2(Ng+1:end,:);
   %LS 
   [H_est,Data]=chan_est_siso(Rx,interval,complex_gold,Nps);
%    H1_est=fft(h1,Nfft,1);
%    H2_est=fft(h2,Nfft,1);
   rx_data=siso_equalization(H_est,Data,SNR,2);
   rx_data=ifft(rx_data,Nfft,1);
   %P->S
   Rx_data=rx_data(:);
   % �����н����ķ��Ž���qpsk���
   demod_bit=step(hDemod,Rx_data);
   nbits_error=0;
   len=min(length(demod_bit),length(msgint));
   nbits_error=nbits_error+sum(xor(demod_bit(1:len),msgint(1:len)));
   ber=nbits_error/len;
   BERs(i)=ber;
end
figure(1), clf, semilogy(SNRs,BERs);
xlabel('Eb/N0(dB)');
ylabel('BER');
title('BER for QPSK modulation(Rayleigh channel)');
figure(2)
plot( Rx_data,'r*');
xlabel('real')
ylabel('image')
title('�����ź�����ͼ');
% save('siso_ber_MQ.mat','BERs');
save('siso_ber_MD.mat','BERs');
