function [hfchan1,hfchan2]=hf_stbc_chan(ts,type);
fd = 1;
if type=='iturHFLQ'
    hfchan1 = stdchan(ts, fd, type);%ÿ�ε����ŵ����Ƕ�����
    hfchan2 = stdchan(ts, fd, type);
end
if type=='iturHFLM'
    hfchan1 = stdchan(ts, fd, type);
    hfchan2 = stdchan(ts, fd, type);
end
if type=='iturHFLD'
    hfchan1 = stdchan(ts, fd, type);
    hfchan2 = stdchan(ts, fd, type);
end
if type=='iturHFMQ'
    hfchan1 = stdchan(ts, fd, type);
    hfchan2 = stdchan(ts, fd, type);
end
if type=='iturHFMM'
    hfchan1 = stdchan(ts, fd, type);
    hfchan2 = stdchan(ts, fd, type);
end
if type=='iturHFMD'
    hfchan1 = stdchan(ts, fd, type);
    hfchan2 = stdchan(ts, fd, type);
end
% if type=='iturHFMDV'
%     hfchan1 = stdchan(ts, fd, type);
%     hfchan2 = stdchan(ts, fd, type);
% end
if type=='iturHFHQ'
    hfchan1 = stdchan(ts, fd, type);
    hfchan2 = stdchan(ts, fd, type);
end
if type=='iturHFHM'
    hfchan1 = stdchan(ts, fd, type);
    hfchan2 = stdchan(ts, fd, type);
end
if type=='iturHFHD'
    hfchan1 = stdchan(ts, fd, type);
    hfchan2 = stdchan(ts, fd, type);
end

%channel 1
%If set to 1, the complex path gain vector is stored as the channel filter function processes the signal. 
%The default value is 0.
hfchan1.StorePathGains = 1;
%If 1, each call to filter resets the state of chan before filtering. 
%If 0, the fading process maintains continuity from one call to the next.
hfchan1.ResetBeforeFiltering = 0;
hfchan1.NormalizePathGains = 1;
%channel 2
hfchan2.StorePathGains = 1;
hfchan2.ResetBeforeFiltering = 0;
hfchan2.NormalizePathGains = 1;