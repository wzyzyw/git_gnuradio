clear all; close all;
Fs=16000;%Hz
ts=1/Fs;
Nfft=64;  Ng=16;  Nofdm=Nfft+Ng;  
% frame_len=3*Nofdm;%һ֡����3��ofdm����
frame_num=40;
Nd=Nfft; % Pilot spacing, Numbers of pilots and data per OFDM symbol
Nsym=Nd*frame_num;%�ܵ�qpsk������
%pilot parameter
pilot_len=Nfft;
bps=2; M=2^bps; % Number of bits per (modulated) symbol
hMod = comm.QPSKModulator('BitInput',true);%default:pi/4,gray map
hDemod = comm.QPSKDemodulator('BitOutput',true);
% pilot_symbol=chu_sequence(Np);%ÿ��ofdm���Ŷ�����ͬ��pilot
% % pilot_symbol=gold_sequence(Np);
% rand('seed',10); 
msgint=randint(bps*Nsym,1); %��������Դ
Data=step(hMod,msgint);
% conse_msgint=comm.ConstellationDiagram('Title','Input bits Consetellation');
% conse_msgint.SymbolsToDisplay=length(Data);
% step(conse_msgint,Data);
%S->P
Sym = reshape(Data,Nd,frame_num);
%add UW
Nps=2; %ʵ�ʲ��뵼Ƶʱ�������ļ��������ȷ����Ƶλ��
Np=frame_num/Nps;%��β���ǵ�Ƶ���������һ�����ŵĲ�ֵ
interval=Nps+1;
all_ofdm=frame_num+Np;
% complex_gold=gold_sequence(pilot_len);
complex_gold=chu_sequence(pilot_len);
[Sym_pilot]=add_pilot_siso(Sym,Nfft,complex_gold,interval,all_ofdm);
%add (CP)
tx = [Sym_pilot(Nfft-Ng+1:Nfft,:);Sym_pilot];
signal=tx(:);
%channel
% [h1,h2]=channel(Nd,all_ofdm,Ng);
[h1,h2]=hf_stbc_chan(ts,'iturHFMQ');
SNRs = [0:2:30];
BERs=zeros(1,length(SNRs));
for i=1:length(SNRs)
   SNR = SNRs(i); 
%    rx=filter(h1,signal1)+filter(h2,signal1);
%    rx=awgn(rx,SNR,'measured');
   rx=[];
for idx=1:all_ofdm
%     rx_tmp=filter(h1(:,idx),1,tx1(:,idx))+filter(h2(:,idx),1,tx2(:,idx));
    rx_tmp=filter(h1,tx(:,idx));
%       rx_tmp=tx(:,idx);
%     rx_tmp=conv(h1,tx1(:,idx))+conv(h2,tx2(:,idx));
    rx_tmp=awgn(rx_tmp,SNR,'measured');
    rx=[rx;rx_tmp];
end

   %S->P
   rx=reshape(rx,Nofdm,all_ofdm);
   %remove cp
   rx_rcp=rx(Ng+1:Nofdm,:);
   %fft dim=1,���н���fft��dim=2,���н���fft
   Rx=fft(rx_rcp,Nfft,1);
%    figure(4)
%    plot( Rx_rcp,'r*');
%    xlabel('real')
%    ylabel('image')
%    title('����Ƶ���ź�����ͼ');
   %decode
%    H1=h1(Ng+1:end,:);
%    H2=h2(Ng+1:end,:);
   %LS 
   [H_est,Data]=chan_est_siso(Rx,interval,complex_gold,Nps);
%    H1_est=fft(h1,Nfft,1);
%    H2_est=fft(h2,Nfft,1);
   rx_data=siso_equalization(H_est,Data,SNR,2);
   rx_data=ifft(rx_data,Nfft,1);
   %P->S
   Rx_data=rx_data(:);
   % �����н����ķ��Ž���qpsk���
   demod_bit=step(hDemod,Rx_data);
   nbits_error=0;
   len=min(length(demod_bit),length(msgint));
   nbits_error=nbits_error+sum(xor(demod_bit(1:len),msgint(1:len)));
   ber=nbits_error/len;
   BERs(i)=ber;
end
figure(1), clf, semilogy(SNRs,BERs);
xlabel('Eb/N0(dB)');
ylabel('BER');
title('BER for QPSK modulation(Rayleigh channel)');
figure(2)
plot( Rx_data,'r*');
xlabel('real')
ylabel('image')
title('�����ź�����ͼ');
% save('siso_ber_MQ.mat','BERs');

