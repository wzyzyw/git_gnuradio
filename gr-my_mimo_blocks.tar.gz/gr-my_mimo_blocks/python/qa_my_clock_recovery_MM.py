#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2018 <+YOU OR YOUR COMPANY+>.
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

from gnuradio import gr, gr_unittest
from gnuradio import blocks,digital
import my_mimo_blocks_swig as my_mimo_blocks
import random
import cmath

class qa_my_clock_recovery_MM (gr_unittest.TestCase):

    def setUp (self):
        self.tb = gr.top_block ()

    def tearDown (self):
        self.tb = None

    def test_001_t (self):
        # set up fg
        omega = 2
        gain_omega = 0.001
        mu = 0.5
        gain_mu = 0.01
        omega_rel_lim = 0.001
        self.test = gr-my_mimo_blocks.my_clock_recovery_MM(omega, gain_omega,mu, gain_mu, omega_rel_lim)
        data = 100*[complex(1, 1),]
        self.src = blocks.vector_source_c(data, False)
        self.snk = blocks.vector_sink_c()

        self.tb.connect(self.src, self.test, self.snk)
        self.tb.run()

        expected_result = 100*[complex(0.99972, 0.99972)] # doesn't quite get to 1.0
        dst_data = self.snk.data()

        # Only compare last Ncmp samples
        Ncmp = 30
        len_e = len(expected_result)
        len_d = len(dst_data)
        expected_result = expected_result[len_e - Ncmp:]
        dst_data = dst_data[len_d - Ncmp:]
        print "expected_result:\n"
        print expected_result
        print "dst_data:\n"
        print dst_data

        self.assertComplexTuplesAlmostEqual(expected_result, dst_data, 5)

        # check data


if __name__ == '__main__':
    gr_unittest.run(qa_my_clock_recovery_MM, "qa_my_clock_recovery_MM.xml")
