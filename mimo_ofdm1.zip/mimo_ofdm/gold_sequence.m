%reffrence
%https://blog.csdn.net/chushengdeniudu/article/details/81060884
%https://blog.csdn.net/heshiliqiu/article/details/78055818
function complex_gold=gold_sequence(s_len);
% clear all;
n=7;
c=[0 1 0 0 0 1 0 0 1];
a=[1 1 1 1 1 1 1 1];
co=[];
m_length=s_len;
for i=1:m_length
    co=[co,a(1)];
    a(8)=mod((a(1)+a(5)),2);
    
    temp=a(2:end);
    a=[temp,a(8)];
end
m1=co;
b=[1 0 1 0 0 0 0 1];
co=[];
for i=1:m_length
    co=[co,b(1)];
    b(8)=mod((b(1)+b(5)),2);
    temp=b(2:end);
    b=[temp,b(8)];
end
m2=co;
gold=xor(m1,m2)';
gold=2*gold-1;
complex_gold=gold+1j*gold;
% y=xcorr(gold);
% figure;
% plot(y);
% hold on;
fid = fopen('gold.txt','w');
for idx=1:m_length
    fprintf(fid,'%d\r\n',gold(idx));
end
fclose(fid);
% r=xcorr(m1);


% gold=2*gold-1;
% complex_gold=gold+1j*gold;
% ebn0=2;%dB
% h1 = (1/sqrt(2)*[randn(m_length,1) + j*randn(m_length,1)]); % Rayleigh channel
% tmp_1=h1.*complex_gold;
% tmp_1=awgn(tmp_1,ebn0,'measured');
% for n=1:600
%     r(n)=0;
%     for idx=1:m_length
%         if mod(idx+n,m_length)==0
%             r(n)=r(n)+complex_gold(idx)*conj(tmp_1(m_length));
%         else
%             r(n)=r(n)+complex_gold(idx)*conj(tmp_1(mod(idx+n,m_length)));
%         end
%     end
% end
% plot(abs(r));
end


