
function [chu]=chu_sequence(s_len);
% clc
% clear all;
len=s_len;
M=3;
chu=[];
fid = fopen('chu.txt','w');
for idx=1:len
    chu=[chu;exp(1j*M*2*pi*idx^2/len)];
    fprintf(fid,'%d\r\n',chu(idx));
end
fclose(fid);
% % %�ڶ���chu����
% chu2=[];
% q=7;
% for idx=1:len
%     chu2(idx)=chu(idx)*exp(1j*2*pi*q*idx/len);
% end
% %%������chu����
% chu3=[];
% q=7+100;%��λ�Ĳ�ֵ������ż��
% for idx=1:len
%     chu3(idx)=chu(idx)*exp(1j*2*pi*q*idx/len);
% end
% len=length(chu2);
% ebn0=2;%dB
% h1 = (1/sqrt(2)*[randn(len,1) + j*randn(len,1)]); % Rayleigh channel
% tmp_1=h1.*chu;
% tmp_1=awgn(tmp_1,ebn0,'measured');
% r=xcorr(chu2,chu3);
% data=chu2+chu3;
% r1=xcorr(data,chu2);
% r2=xcorr(data,chu3);
% for n=1:128
%     r(n)=0;
%     for idx=1:len
%         if mod(idx+n,len)==0
%             r(n)=r(n)+chu2(idx)*conj(chu3(len));
%         else
%             r(n)=r(n)+chu2(idx)*conj(chu3(mod(idx+n,len)));
%         end
%     end
% end
% % plot(abs(r));
% % figure;
% % plot(abs(r2));
% % figure;
% % r3=xcorr(chu2);
% % plot(abs(r3));
% % figure(1)
% % plot(chu,'r*');
% % xlabel('real')
% % ylabel('image')
end
        


