function [H1,H2]=ls_chan_est(rx_pilot1,rx_pilot2,pilot_symbol,frame_num,Nps)
NumLoop=frame_num;
NT=Nps;
[carrier_count,Np]=size(rx_pilot1);
matrix_pilot=kron(ones(1,Np),pilot_symbol);
LS_est1=rx_pilot1./matrix_pilot;
LS_est2=rx_pilot2./matrix_pilot;

%interpolate
Hls=zeros(2,1,carrier_count,Np);
Hls(1,1,:,:)=LS_est1;
Hls(2,1,:,:)=LS_est2;
HLs=zeros(2,1,carrier_count,NumLoop);
for idx=1:2
    if ceil(NumLoop/NT)==NumLoop/NT
        for k=1:Np-1
              for t=1:NT
               HLs(idx,1,:,(k-1)*NT+t)=(Hls(idx,1,:,k+1)-Hls(idx,1,:,k))*t/(NT+2)+Hls(idx,1,:,k);
%                fprintf('(k)Hls_r=%f,Hls_i=%f\n',real(Hls(idx,1,:,k)),imag(Hls(idx,1,:,k)));
%                fprintf('(k+1)Hls_r=%f,Hls_i=%f\n',real(Hls(idx,1,:,k+1)),imag(Hls(idx,1,:,k+1)));
%                fprintf('(inter)Hls_r=%f,Hls_i=%f\n',real(HLs(idx,1,:,(k-1)*NT+t)),imag(HLs(idx,1,:,(k-1)*NT+t)));
              end
        end
    else
        for k=1:Np-2
            for t=1:NT
                HLs(idx,1,:,(k-1)*NT+t)=(Hls(idx,1,:,k+1)-Hls(idx,1,:,k))*t/(NT+2)+Hls(idx,1,:,k);
            end
        end
        for t=1:mod(NumLoop,NT)
            HLs(idx,1,:,(Np-2)*NT+t)=(Hls(idx,1,:,Np)-Hls(idx,1,:,Np-1))*t/(mod(NumLoop,NT)+2)+Hls(idx,1,:,Np-1);
        end;
    end
end
H1(:,:)=HLs(1,1,:,:);
H2(:,:)=HLs(2,1,:,:);
idx=1;
while idx<=carrier_count
%     fprintf('idx=%d\n',idx);
    tmp1=(H1(idx,:)+H1(idx+1,:))./2;
    H1(idx,:)=tmp1;
    H1(idx+1,:)=tmp1;
    tmp2=(H2(idx,:)+H2(idx+1,:))/2;
    H2(idx,:)=tmp2;
    H2(idx+1,:)=tmp2;
    idx=idx+2;
end

