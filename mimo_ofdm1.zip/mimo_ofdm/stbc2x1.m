function [encode_data1,encode_data2]=stbc2x1(Data,Nfft,frame_num);
carrier_count=Nfft;
Sym=Data;
NumLoop=frame_num;
encode_data1 = zeros(carrier_count,NumLoop);
encode_data2 = zeros(carrier_count,NumLoop);
SymFFTtmp = reshape(Sym,carrier_count,NumLoop);
%alamouti���벢����ת��
encode_data1(:,1:2:end)=SymFFTtmp(:,1:2:end);
encode_data2(:,1:2:end)=SymFFTtmp(:,2:2:end);
encode_data1(:,2:2:end)=-conj(SymFFTtmp(:,2:2:end));
encode_data2(:,2:2:end)=conj(SymFFTtmp(:,1:2:end));
end