function R_Data=sfbc_decode_2x1(H1,H2,input_data)
[carrier_count,NumLoop]=size(H1);
R_Data = zeros(carrier_count,NumLoop);
ReData_y1=input_data;
for jj = 1:NumLoop
    for ii = 1:2:carrier_count-1
        R_Data(ii,jj) = conj(H1(ii,jj))*ReData_y1(ii,jj) + H2(ii+1,jj)*conj(ReData_y1(ii+1,jj));                     
        R_Data(ii+1,jj) = conj(H2(ii,jj))*ReData_y1(ii,jj) - H1(ii+1,jj)*conj(ReData_y1(ii+1,jj));                   
    end
end