clear all; close all;
Nfft=512;  Ng=64;  Nofdm=Nfft+Ng;  
% frame_len=3*Nofdm;%һ֡����3��ofdm����
frame_num=40;
Nps=4; Np=Nfft/Nps; Nd=Nfft%-2*Np; % Pilot spacing, Numbers of pilots and data per OFDM symbol
Nsym=Nd*frame_num;%�ܵ�qpsk������
bps=2; M=2^bps; % Number of bits per (modulated) symbol
mod_object = modem.dpskmod('M', M, 'InitialPhase', pi/4,'SymbolOrder','gray','INPUTTYPE','Bit');
demod_object=modem.dpskdemod('M', M, 'InitialPhase', pi/4,'SymbolOrder','gray','OutputType','Bit');
% pilot_symbol=chu_sequence(Np);%ÿ��ofdm���Ŷ�����ͬ��pilot
pilot_symbol=gold_sequence(Np);
% rand('seed',10); 
msgint=randint(bps*Nsym,1); %��������Դ
Data = modulate(mod_object,msgint);%qpsk modulation �������Ҫ��������
%alamouti encode
[encode_data1,encode_data2]=sfbc2x1(Data,Nd,frame_num);
%add pilot
carrier_count=1;
id_pilot=1;
ip=0;
% while carrier_count<=Nfft
%     if mod(carrier_count,Nps)==1
%         X1(carrier_count,:) = kron(ones(1,frame_num),pilot_symbol(id_pilot));
%         X1(carrier_count+1,:) = zeros(1,frame_num);
%         X2(carrier_count,:) = zeros(1,frame_num);
%         X2(carrier_count+1,:)=kron(ones(1,frame_num),pilot_symbol(id_pilot));
%         ip=ip+2;%������Ƶռ��������λ
%         carrier_count=carrier_count+2;
%         id_pilot=id_pilot+1;
%      else
%         X1(carrier_count,:) = encode_data1(carrier_count-ip,:);
%         X2(carrier_count,:) = encode_data2(carrier_count-ip,:);
%         carrier_count=carrier_count+1;
%     end    
% end
X1=encode_data1;
X2=encode_data2;
%IFFT
x1=ifft(X1,Nfft,1);
x2=ifft(X2,Nfft,1);
%add CP and generate frame
tx1_tmp = [x1(Nfft-Ng+1:Nfft,:);x1];
tx2_tmp = [x2(Nfft-Ng+1:Nfft,:);x2];
%P->S
tx1=tx1_tmp(:);%���������е�˳�򹹳�������
tx2=tx2_tmp(:);
% tx1=tx1_tmp;
% tx2=tx2_tmp;

%channel
h_len_ofdm=10;
h1 = (1/sqrt(2)*[randn(1,h_len_ofdm) + j*randn(1,h_len_ofdm)]); % Rayleigh channel
h2 = (1/sqrt(2)*[randn(1,h_len_ofdm) + j*randn(1,h_len_ofdm)]); 
rx1=filter(h1,1,tx1);
rx2=filter(h2,1,tx2);
% [rx1,rx2]=channel(Nd,frame_num,Nfft,tx1,tx2,Ng)


%add gaussion noise
SNRs = [0:30];  sq2=sqrt(2);
BERs=zeros(1,length(SNRs));
for i=1:length(SNRs)
   SNR = SNRs(i); 
   rx1=awgn(rx1,SNR,'measured');
   rx2=awgn(rx2,SNR,'measured');
   rx_tmp=rx1+rx2;
   %S->P
   rx=reshape(rx_tmp,Nfft+Ng,frame_num);
   %remove cp
   rx_rcp=rx(Ng+1:Nofdm,:);
   %fft dim=1,���н���fft��dim=2,���н���fft
   Rx_rcp=fft(rx_rcp,Nfft,1);
   %���뵼Ƶ������
   rx_data=[];
   ip=0;
   id_carrier=1;
   pilot_loc1=[];
   pilot_loc2=[];
   data_loc=[];
   while id_carrier<=size(Rx_rcp,1)   
       if mod(id_carrier,Nps)==1
            pilot_loc1 = [pilot_loc1 id_carrier]; 
            pilot_loc2 = [pilot_loc2 id_carrier+1];
            ip = ip+2;
            id_carrier=id_carrier+2;
       else
            data_loc=[data_loc,id_carrier];
            id_carrier=id_carrier+1;
       end
   end
   rx_pilot1=Rx_rcp(pilot_loc1,:);
   rx_pilot2=Rx_rcp(pilot_loc2,:);
   Rx_data_tmp=Rx_rcp(data_loc,:);%�ҵ�һ��ofdm���������ݷ���
   
   %channel estimate
   [H1_est,H2_est]=ls_chan_est2(rx_pilot1,rx_pilot2,pilot_symbol,Nfft);
   %alamouti����
   rx_data=sfbc_decode_2x1(H1_est,H2_est,Rx_data_tmp);
   %P->S
   Rx_data=rx_data(:);
   % �����н����ķ��Ž���qpsk���
   demod_bit = demodulate(demod_object,Rx_data);
   nbits_error=0;
   len=min(length(demod_bit),length(msgint));
   nbits_error=nbits_error+sum(xor(demod_bit(1:len),msgint(1:len)));
   ber=nbits_error/len;
   BER(i)=ber;
end
figure(1), clf, semilogy(SNRs,BER);
xlabel('Eb/N0(dB)');
ylabel('BER');
title('BER for QPSK modulation with Alamouti STBC (Rayleigh channel)');


