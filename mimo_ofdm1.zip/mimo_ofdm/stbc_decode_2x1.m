function R_Data=stbc_decode_2x1(H1_est,H2_est,input_data)
[carrier_count,NumLoop]=size(input_data);
R_Data = zeros(carrier_count,NumLoop);
y=input_data;
for ii= 1:carrier_count
    for jj = 1:2:NumLoop-1
        tmp_y=[y(ii,jj);conj(y(ii,jj+1))];
        tmp_H=[H1_est(ii,jj),H2_est(ii,jj);conj(H2_est(ii,jj)),-conj(H1_est(ii,jj))];
        tmp_H_power=abs(H1_est(ii,jj))^2+abs(H2_est(ii,jj))^2;
        R_Data(ii,jj:jj+1)=tmp_H'*tmp_y./(tmp_H_power);                   
    end
end
