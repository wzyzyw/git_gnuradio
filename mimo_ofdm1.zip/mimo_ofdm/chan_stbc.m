function [h1,h2]=chan_stbc(Nd,frame_num,Ng)
h_len=frame_num/2;
h1_tmp = (1/sqrt(2)*[randn(1,h_len) + 1j*randn(1,h_len)]);
h2_tmp = (1/sqrt(2)*[randn(1,h_len) + 1j*randn(1,h_len)]);
tmp1=kron(h1_tmp,ones(1,2));
h1=kron(ones(Nd+Ng,1),tmp1);
tmp2=kron(h2_tmp,ones(1,2));
h2=kron(ones(Nd+Ng,1),tmp2);