
clear all; close all;
Nt=2;%����������
Nfft=512;  Ng=64;  Nofdm=Nfft+Ng;  
% frame_len=3*Nofdm;%һ֡����3��ofdm����
frame_num=40;
Nps=4; interval=Nps+Nt;%ʵ�ʲ��뵼Ƶʱ�������ļ��������ȷ����Ƶλ��
Np=frame_num/Nps; Nd=Nfft;%-2*Np; % Pilot spacing, Numbers of pilots and data per OFDM symbol
Nsym=Nd*frame_num;%�ܵ�qpsk������
bps=2; M=2^bps; % Number of bits per (modulated) symbol
mod_object = modem.dpskmod('M', M, 'InitialPhase', pi/4,'SymbolOrder','gray','INPUTTYPE','Bit');
demod_object=modem.dpskdemod('M', M, 'InitialPhase', pi/4,'SymbolOrder','gray','OutputType','Bit');
% pilot_symbol=chu_sequence(Np);%ÿ��ofdm���Ŷ�����ͬ��pilot
pilot_symbol=gold_sequence(Nfft);
% rand('seed',10); 
msgint=randint(bps*Nsym,1); %��������Դ
Data = modulate(mod_object,msgint);%qpsk modulation �������Ҫ��������
%alamouti encode
[encode_data1,encode_data2]=sfbc2x1(Data,Nfft,frame_num);
%add block pilot
all_time=frame_num+2*Np;
ofdm_count=1;
ip=0;
while ofdm_count<=all_time
    if mod(ofdm_count,interval)==1
        X1(:,ofdm_count) = pilot_symbol;
        X1(:,ofdm_count+1) = zeros(length(pilot_symbol),1);
        X2(:,ofdm_count) = zeros(length(pilot_symbol),1);
        X2(:,ofdm_count+1)=pilot_symbol;
        ip=ip+2;%������Ƶռ��������λ
        ofdm_count=ofdm_count+2;
     else
        X1(:,ofdm_count) = encode_data1(:,ofdm_count-ip);
        X2(:,ofdm_count) = encode_data2(:,ofdm_count-ip);
        ofdm_count=ofdm_count+1;
    end    
end
%IFFT
x1=ifft(X1,Nfft,1);
x2=ifft(X2,Nfft,1);
%add CP and generate frame
tx1_tmp = [x1(Nfft-Ng+1:Nfft,:);x1];
tx2_tmp = [x2(Nfft-Ng+1:Nfft,:);x2];
%P->S
tx1=tx1_tmp(:);%���������е�˳�򹹳�������
tx2=tx2_tmp(:);
%channel
% h_len=length(tx1);
% h1 = (1/sqrt(2)*[randn(1,Nfft/4) + j*randn(1,Nfft/4)]); % Rayleigh channel
% h2 = (1/sqrt(2)*[randn(1,Nfft/4) + j*randn(1,Nfft/4)]); 
load 'F:\matlab_code\mimo_ofdm\h1.mat';
load 'F:\matlab_code\mimo_ofdm\h2.mat';
h1=h11;
h2=h12;
rx1=filter(h1,1,tx1);
rx2=filter(h2,1,tx2);
% rx1=convtx1;
% rx2=tx2;
%add gaussion noise
SNRs = [0:30];  sq2=sqrt(2);
BERs=zeros(1,length(SNRs));
for i=1:length(SNRs)
   SNR = SNRs(i); 
   rx1=awgn(rx1,SNR,'measured');
   rx2=awgn(rx2,SNR,'measured');
   rx_tmp=rx1+rx2;
   %S->P
   rx=reshape(rx_tmp,Nofdm,frame_num+2*Np);
   %remove cp
   rx_rcp=rx(Ng+1:Nofdm,:);
   %fft dim=1,���н���fft��dim=2,���н���fft
   Rx_rcp=fft(rx_rcp,Nfft,1);
   %���뵼Ƶ������
   id_ofdm=1;
   pilot_loc1=[];
   pilot_loc2=[];
   data_loc=[];
   while id_ofdm<=size(Rx_rcp,2)   
       if mod(id_ofdm,interval)==1
            pilot_loc1 = [pilot_loc1 id_ofdm]; 
            pilot_loc2 = [pilot_loc2 id_ofdm+1];
            ip = ip+2;
            id_ofdm=id_ofdm+2;
       else
            data_loc=[data_loc,id_ofdm];
            id_ofdm=id_ofdm+1;
       end
   end
   rx_pilot1=Rx_rcp(:,pilot_loc1);
   rx_pilot2=Rx_rcp(:,pilot_loc2);
   Rx_data_tmp=Rx_rcp(:,data_loc);%�ҵ�һ��ofdm���������ݷ���
   %channel estimate
   [H1_est,H2_est]=ls_chan_est(rx_pilot1,rx_pilot2,pilot_symbol,frame_num,Nps);
   %alamouti����
   rx_data=sfbc_decode_2x1(H1_est,H2_est,Rx_data_tmp);
   %P->S
   Rx_data=rx_data(:);
   % �����н����ķ��Ž���qpsk���
   demod_bit = demodulate(demod_object,Rx_data);
   nbits_error=0;
   len=min(length(demod_bit),length(msgint));
   nbits_error=nbits_error+sum(xor(demod_bit(1:len),msgint(1:len)));
   ber=nbits_error/len;
   BER(i)=ber;
end
figure(1), clf, semilogy(SNRs,BER);
xlabel('Eb/N0(dB)');
ylabel('BER');
title('BER for QPSK modulation with Alamouti STBC (Rayleigh channel)');