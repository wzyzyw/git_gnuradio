function [rx1,rx2]=channel(Nd,frame_num,Nfft,tx1,tx2,Ng)
h_len_ofdm=Nd/2;
H1=zeros(Nd,frame_num);
H2=zeros(Nd,frame_num);
for idx=1:frame_num
    tmp_h1 = (1/sqrt(2)*[randn(1,h_len_ofdm) + j*randn(1,h_len_ofdm)]);
    tmp_h2 = (1/sqrt(2)*[randn(1,h_len_ofdm) + j*randn(1,h_len_ofdm)]);
    H1(1:2:end,idx)=tmp_h1;
    H1(2:2:end,idx)=tmp_h1;
    H2(1:2:end,idx)=tmp_h2;
    H2(2:2:end,idx)=tmp_h2;
end
h1=ifft(H1,Nfft,1);
h2=ifft(H2,Nfft,1);
r1=zeros(Nfft+Ng,frame_num);
r2=zeros(Nfft+Ng,frame_num);
for idx=1:frame_num
    r1(:,idx)=filter(h1(:,idx),1,tx1(:,idx));
    r2(:,idx)=filter(h2(:,idx),1,tx2(:,idx));
end
rx1=r1(:);
rx2=r2(:);
% h1 = (1/sqrt(2)*[randn(1,h_len_ofdm) + j*randn(1,h_len_ofdm)]); % Rayleigh channel
% h2 = (1/sqrt(2)*[randn(1,h_len_ofdm) + j*randn(1,h_len_ofdm)]); 