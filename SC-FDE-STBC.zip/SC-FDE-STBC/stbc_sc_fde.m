clear all; close all;
Nfft=64;  Ng=16;  Nofdm=Nfft+Ng;  
% frame_len=3*Nofdm;%һ֡����3��ofdm����
frame_num=40;
Nd=Nfft; % Pilot spacing, Numbers of pilots and data per OFDM symbol
Nsym=Nd*frame_num;%�ܵ�qpsk������
%pilot parameter
Nps=4; 
pilot_len=Nfft;
bps=2; M=2^bps; % Number of bits per (modulated) symbol
hMod = comm.QPSKModulator('BitInput',true);%default:pi/4,gray map
hDemod = comm.QPSKDemodulator('BitOutput',true);
% pilot_symbol=chu_sequence(Np);%ÿ��ofdm���Ŷ�����ͬ��pilot
% % pilot_symbol=gold_sequence(Np);
% rand('seed',10); 
msgint=randint(bps*Nsym,1); %��������Դ
Data=step(hMod,msgint);
conse_msgint=comm.ConstellationDiagram('Title','Input bits Consetellation');
conse_msgint.SymbolsToDisplay=length(Data);
step(conse_msgint,Data);
%alamouti encode
[encode1,encode2]=sc_stbc(Data,Nd,frame_num);

%add UW
Nps=4; %ʵ�ʲ��뵼Ƶʱ�������ļ��������ȷ����Ƶλ��
Np=frame_num/Nps;%��β���ǵ�Ƶ���������һ�����ŵĲ�ֵ
interval=Nps+2;
all_ofdm=frame_num+Np*2;
complex_gold=gold_sequence(pilot_len);
% complex_gold=chu_sequence(pilot_len);
[encode1_pilot,encode2_pilot]=add_pilot(encode1,encode2,Nfft,complex_gold,interval,all_ofdm);
% encode1_pilot=encode1
% encode2_pilot=encode2;
%add (CP)
tx1 = [encode1_pilot(Nfft-Ng+1:Nfft,:);encode1_pilot];
tx2 = [encode2_pilot(Nfft-Ng+1:Nfft,:);encode2_pilot];
% gold_matrix=kron(ones(1,frame_num),complex_gold);
% tx1=encode_data1;
% tx2=encode_data2;
% tx1=[gold_matrix;tx1];
% tx2=[gold_matrix;tx2];
% figure(5)
% plot( tx1,'r*');
% xlabel('real')
% ylabel('image')
% title('�����ź�����ͼ');
%channel
[h1,h2]=channel(Nd,all_ofdm,Ng);
SNRs = [0:30];
BERs=zeros(1,length(SNRs));
for i=1:length(SNRs)
   SNR = SNRs(i); 
   rx=[];
for idx=1:all_ofdm
    rx_tmp=filter(h1(:,idx),1,tx1(:,idx))+filter(h2(:,idx),1,tx2(:,idx));
    rx_tmp=awgn(rx_tmp,SNR,'measured');
    rx=[rx;rx_tmp];
end
% rx1_tmp=h1.*tx1;
% rx2_tmp=h2.*tx2;
% rx1=ifft(Rx1,Nfft+Ng,1);
% rx2=ifft(Rx2,Nfft+Ng,1);

% for idx=1:frame_num
%     rx1(:,idx)=filter(H1(:,idx),1,tx1(:,idx));
%     rx2(:,idx)=filter(H2(:,idx),1,tx2(:,idx));
% end
%P->S
% rx1_tmp=rx1_tmp(:);
% rx2_tmp=rx2_tmp(:);
%add gaussion noise

%    rx2=rx2_tmp;
%    rx1=awgn(rx1,SNR,'measured');
%    rx2=awgn(rx2,SNR,'measured');
%    rx_tmp=rx1+rx2;
   %S->P
   rx=reshape(rx,Nofdm,all_ofdm);
   %remove cp
   rx_rcp=rx(Ng+1:Nofdm,:);
   %fft dim=1,���н���fft��dim=2,���н���fft
   Rx=fft(rx_rcp,Nfft,1);
%    figure(4)
%    plot( Rx_rcp,'r*');
%    xlabel('real')
%    ylabel('image')
%    title('����Ƶ���ź�����ͼ');
   %decode
%    H1=h1(Ng+1:end,:);
%    H2=h2(Ng+1:end,:);
   %LS 
   [H1_est,H2_est,Data]=chan_est_block(Rx,interval,complex_gold,Nps);
%    H1_est=fft(h1,Nfft,1);
%    H2_est=fft(h2,Nfft,1);
   rx_data=sc_stbc_decode(H1_est,H2_est,Data);
   rx_data=ifft(rx_data,Nfft,1);
   %P->S
   Rx_data=rx_data(:);
   % �����н����ķ��Ž���qpsk���
   demod_bit=step(hDemod,Rx_data);
   nbits_error=0;
   len=min(length(demod_bit),length(msgint));
   nbits_error=nbits_error+sum(xor(demod_bit(1:len),msgint(1:len)));
   ber=nbits_error/len;
   BERs(i)=ber;
end
figure(1), clf, semilogy(SNRs,BERs);
xlabel('Eb/N0(dB)');
ylabel('BER');
title('BER for QPSK modulation with Alamouti STBC (Rayleigh channel)');
figure(2)
plot( Rx_data,'r*');
xlabel('real')
ylabel('image')
title('�����ź�����ͼ');

