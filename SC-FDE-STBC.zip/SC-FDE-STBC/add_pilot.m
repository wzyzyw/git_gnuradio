function [encode1_pilot,encode2_pilot]=add_pilot(encode1,encode2,Nfft,complex_gold,interval,all_ofdm)
%sum OFDM
encode1_pilot=zeros(Nfft,all_ofdm);
encode2_pilot=zeros(Nfft,all_ofdm);
idx=1;
ip=0;
%add
while idx<=all_ofdm
    if mod(idx,interval)==1
        encode1_pilot(:,idx:idx+1)=[complex_gold,zeros(Nfft,1)];
        encode2_pilot(:,idx:idx+1)=[zeros(Nfft,1),complex_gold];
        idx=idx+2;
        ip=ip+2;
    else
        encode1_pilot(:,idx)=encode1(:,idx-ip);
        encode2_pilot(:,idx)=encode2(:,idx-ip);
        idx=idx+1;
    end
end